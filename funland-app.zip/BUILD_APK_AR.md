# Funland — دليل تشغيل وبناء APK

## ما تم تحديثه

- إعادة تصميم واجهة لوحة التحكم بهوية فاخرة متجاوبة مع الهاتف والويب.
- الحفاظ على وظائف الجداول، إدارة استراحات الموظفين، المؤقتات، التنبيهات، التقارير، الإعدادات، الأصوات والنسخ الاحتياطي.
- توحيد الهوية البصرية بدرجات teal/gold مع دعم الوضع الداكن.
- إضافة مؤشرات تشغيل مباشرة، بطاقات إحصائية أوضح، وحالة ثقة للحفظ المحلي.
- تحويل إعداد Capacitor إلى `capacitor.config.json` لتفادي مشاكل تحميل TypeScript في بيئات CI.
- إضافة GitHub Actions في `.github/workflows/android-apk.yml` لبناء APK تلقائيًا.

## التشغيل المحلي للويب

```bash
npm ci
npm run dev
```

## بناء Android محليًا

يتطلب Android SDK وJDK 21:

```bash
npm ci
npm run android:build
```

الناتج:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

## البناء من GitHub

1. ارفع مجلد المشروع كاملًا إلى مستودع GitHub.
2. افتح تبويب **Actions**.
3. شغّل **Build Funland APK** يدويًا من زر **Run workflow**، أو ادفع إلى فرع `main`/`master`.
4. بعد انتهاء المهمة، افتح التشغيل الناجح ثم نزّل artifact باسم `funland-debug-apk`.
5. فك الضغط لتحصل على `app-debug.apk` وتثبته على جهاز Android للاختبار.

> هذا APK تجريبي (Debug). للنشر على Google Play يلزم إنشاء مفتاح توقيع Release وإضافة إعدادات التوقيع إلى GitHub Secrets.
