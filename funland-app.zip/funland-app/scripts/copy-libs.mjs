// ينسخ مكتبتي html2canvas و jsPDF من node_modules إلى public/libs
// ليعمل قسم «جداول فن لاند» (تصدير PDF/صورة) بدون إنترنت داخل التطبيق.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = path.join(root, 'public', 'libs');
fs.mkdirSync(out, { recursive: true });

const files = [
  ['node_modules/html2canvas/dist/html2canvas.min.js', 'html2canvas.min.js'],
  ['node_modules/jspdf/dist/jspdf.umd.min.js', 'jspdf.umd.min.js'],
];
for (const [from, to] of files) {
  const src = path.join(root, from);
  if (!fs.existsSync(src)) {
    console.error(`ملف ناقص: ${from}\nشغّل: npm install`);
    process.exit(1);
  }
  fs.copyFileSync(src, path.join(out, to));
}
console.log('copy-libs: تم نسخ مكتبات الجداول ✔');
