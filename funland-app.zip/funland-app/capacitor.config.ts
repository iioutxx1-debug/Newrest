import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.miqatalfajr.smartalarm',
  appName: 'Funland',
  webDir: 'dist',
  backgroundColor: '#F4F7FB',
  android: {
    backgroundColor: '#F4F7FB',
  },
  plugins: {
    LocalNotifications: {
      smallIcon: 'ic_stat_icon_config_sample',
      iconColor: '#F59E0B',
      sound: 'beep.wav',
    },
  },
};

export default config;
