const ADMIN_PIN_KEY = 'funland_admin_pin_v1';

/** UI-level confirmation only; this is not cryptographic device security. */
export function verifyAdminPin(actionLabel: string): boolean {
  try {
    let saved = localStorage.getItem(ADMIN_PIN_KEY);
    if (!saved) {
      const first = window.prompt(`لحماية ${actionLabel}، أنشئ رمز مدير من 4 أرقام/أحرف على الأقل:`);
      if (!first || first.trim().length < 4) return false;
      const confirm = window.prompt('أعد إدخال رمز المدير للتأكيد:');
      if (confirm !== first) { window.alert('الرمزان غير متطابقين.'); return false; }
      saved = first;
      localStorage.setItem(ADMIN_PIN_KEY, saved);
    }
    return window.prompt(`أدخل رمز المدير للمتابعة: ${actionLabel}`) === saved;
  } catch {
    return false;
  }
}

export function hasAdminPin(): boolean {
  try { return Boolean(localStorage.getItem(ADMIN_PIN_KEY)); } catch { return false; }
}

export function setAdminPin(pin: string): void {
  if (pin.trim().length < 4) throw new Error('يجب أن يتكون الرمز من 4 أحرف/أرقام على الأقل.');
  localStorage.setItem(ADMIN_PIN_KEY, pin);
}

export function changeAdminPin(): boolean {
  if (hasAdminPin() && !verifyAdminPin('تغيير رمز المدير')) return false;
  const first = window.prompt('أدخل رمز المدير الجديد (4 أحرف/أرقام على الأقل):');
  if (!first || first.trim().length < 4) return false;
  const confirm = window.prompt('أعد إدخال الرمز الجديد:');
  if (first !== confirm) { window.alert('الرمزان غير متطابقين.'); return false; }
  setAdminPin(first);
  return true;
}
