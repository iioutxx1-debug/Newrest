import { SoundType, SoundSourceType } from '../types';
import { getImportedSongs, getBlobFromIndexedDB } from './audioLibraryStore';
import { nativeAlarmBridge } from './nativeAlarmBridge';
import { schedulePattern, loopSeconds, patternSeconds, DEFAULT_TONE } from './toneLibrary';

export interface RestAlarmOptions {
  source: SoundSourceType;
  sound: SoundType;
  customUri?: string;
  customSongId?: string;
  volume: number; // 0.1 .. 1
  vibrate: boolean;
  ttsText?: string;
}

type PlayResult = { ok: boolean; error?: string };

/**
 * محرك صوت التنبيهات.
 *
 * قاعدة العمل الأساسية: «مصدر صوت واحد فقط في أي لحظة».
 *  - كل تشغيل جديد يبدأ بـ stop() الذي يُنهي كل شيء (النغمات المجدولة، الملف، الصوت الأصلي، النطق).
 *  - `token` يلغي أي عملية غير متزامنة متأخرة (مثل تحميل ملف) إذا بدأ تشغيل أحدث أو تم الإيقاف.
 *  - استدعاء startRestExpiredLoop بنفس الإعدادات أثناء الرنين لا يعيد التشغيل (idempotent).
 *  - النطق الصوتي لا يعمل أبداً فوق النغمة: إمّا قبلها أو في دورة بديلة عنها.
 */
class AlarmAudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;

  private token = 0;
  private isPlaying = false;
  private activeKey: string | null = null;

  private loopTimer: number | null = null;
  private vibTimer: number | null = null;
  private maxTimer: number | null = null;
  private previewTimer: number | null = null;

  private htmlAudio: HTMLAudioElement | null = null;
  private currentObjectUrl: string | null = null;
  private utterance: SpeechSynthesisUtterance | null = null;
  private ttsText: string | undefined;

  // ───────────────────────── أدوات داخلية ─────────────────────────
  private initContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private createMaster(volume: number): GainNode {
    const ctx = this.initContext();
    this.killMaster();
    const g = ctx.createGain();
    g.gain.value = Math.max(0.05, Math.min(1, volume));
    g.connect(ctx.destination);
    this.master = g;
    return g;
  }

  /** يقطع الصوت المُولَّد فوراً، بما في ذلك النوتات المجدولة مسبقاً. */
  private killMaster() {
    if (!this.master) return;
    try {
      this.master.gain.cancelScheduledValues(0);
      this.master.gain.value = 0;
      this.master.disconnect();
    } catch {}
    this.master = null;
  }

  private clearTimers() {
    if (this.loopTimer !== null) {
      clearTimeout(this.loopTimer);
      this.loopTimer = null;
    }
    if (this.vibTimer !== null) {
      clearInterval(this.vibTimer);
      this.vibTimer = null;
    }
    if (this.maxTimer !== null) {
      clearTimeout(this.maxTimer);
      this.maxTimer = null;
    }
    if (this.previewTimer !== null) {
      clearTimeout(this.previewTimer);
      this.previewTimer = null;
    }
  }

  private releaseHtmlAudio() {
    if (this.htmlAudio) {
      try {
        this.htmlAudio.pause();
        this.htmlAudio.currentTime = 0;
        this.htmlAudio.src = '';
      } catch {}
      this.htmlAudio = null;
    }
    if (this.currentObjectUrl) {
      try {
        URL.revokeObjectURL(this.currentObjectUrl);
      } catch {}
      this.currentObjectUrl = null;
    }
  }

  private cancelSpeech() {
    this.utterance = null;
    try {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    } catch {}
  }

  private speak(text: string, volume: number, onDone: () => void) {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      onDone();
      return;
    }
    let finished = false;
    const done = () => {
      if (finished) return;
      finished = true;
      onDone();
    };
    try {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'ar-SA';
      u.rate = 1.0;
      u.volume = Math.min(1, volume);
      u.onend = done;
      u.onerror = done;
      this.utterance = u; // مرجع يمنع تنظيف الذاكرة قبل انتهاء النطق
      window.speechSynthesis.speak(u);
    } catch {
      done();
    }
  }

  private vibrateOnce() {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate([400, 200, 400]);
      } catch {}
    }
  }

  /** هل يرنّ الآن تنبيه فعلي (انتهاء استراحة)؟ المعاينات لا تُحتسب. */
  public isAlarmRinging(): boolean {
    return this.isPlaying;
  }

  // ───────────────────────── الإيقاف ─────────────────────────
  /** يوقف كل صوت: النغمات، الملفات، الصوت الأصلي لأندرويد، والنطق. */
  public stop() {
    this.token++;
    this.isPlaying = false;
    this.activeKey = null;
    this.clearTimers();
    this.killMaster();
    this.releaseHtmlAudio();
    this.cancelSpeech();
    nativeAlarmBridge.stopNativeUriAudio();
  }

  // ───────────────────────── المعاينة ─────────────────────────
  /** معاينة نغمة مدمجة (تُشغَّل مرة واحدة ثم تتوقف تلقائياً). */
  public playPreview(sound: SoundType, volume: number = 0.6) {
    if (this.isPlaying) return; // لا نقطع رنين تنبيه فعلي بمعاينة
    this.stop();
    const token = this.token;
    const master = this.createMaster(volume);
    const ctx = this.ctx as AudioContext;
    schedulePattern(ctx, master, sound, ctx.currentTime + 0.02);
    this.previewTimer = window.setTimeout(() => {
      if (token === this.token) this.stop();
    }, patternSeconds(sound) * 1000 + 150);
  }

  /** معاينة نغمة هاتف أو أغنية من «أغنياتي» (مصدر واحد، مع حد أقصى للمدة). */
  public async playCustomSourcePreview(options: {
    soundSource: SoundSourceType;
    sound: SoundType;
    customSoundUri?: string;
    customSongId?: string;
    volume?: number;
  }): Promise<PlayResult> {
    if (this.isPlaying) {
      return { ok: false, error: 'لا يمكن المعاينة أثناء رنين تنبيه فعلي. أوقفه أولاً.' };
    }
    this.stop();
    const volume = options.volume ?? 0.8;

    if (options.soundSource === 'app_tone') {
      this.playPreview(options.sound, volume);
      return { ok: true };
    }

    const token = this.token;

    if (options.soundSource === 'phone_ringtone') {
      if (!options.customSoundUri) {
        return { ok: false, error: 'لم يتم اختيار نغمة هاتف بعد.' };
      }
      if (!nativeAlarmBridge.isNativeAndroid()) {
        return {
          ok: false,
          error: 'تشغيل نغمات نظام أندرويد (content://) يتطلب تشغيل التطبيق على هاتف أندرويد.',
        };
      }
      return this.playFileSource(options.customSoundUri, undefined, false, 15, volume, token);
    }

    if (options.soundSource === 'my_song') {
      const songs = getImportedSongs();
      const song =
        songs.find((s) => s.id === options.customSongId) ||
        songs.find((s) => s.uri === options.customSoundUri);
      if (!song) {
        return { ok: false, error: 'الأغنية المحددة غير موجودة في مكتبة «أغنياتي».' };
      }
      return this.playFileSource(song.uri, song.id, false, 30, volume, token);
    }

    return { ok: true };
  }

  // ───────────────────────── تشغيل ملف (idb:// أو file:// أو content://) ─────────────────────────
  private async playFileSource(
    uri: string,
    songId: string | undefined,
    loop: boolean,
    maxSeconds: number,
    volume: number,
    token: number
  ): Promise<PlayResult> {
    const vol = Math.max(0.1, Math.min(1, volume));

    if (uri.startsWith('idb://')) {
      const id = songId || uri.replace('idb://', '');
      const blob = await getBlobFromIndexedDB(id);
      if (token !== this.token) return { ok: true }; // أُلغي أثناء التحميل
      if (!blob || blob.size === 0) {
        return { ok: false, error: 'تعذر العثور على بيانات الملف الصوتي المحفوظة محلياً.' };
      }
      try {
        const objUrl = URL.createObjectURL(blob);
        const audio = new Audio(objUrl);
        audio.loop = loop;
        audio.volume = vol;
        this.releaseHtmlAudio();
        this.currentObjectUrl = objUrl;
        this.htmlAudio = audio;
        await audio.play();
        if (token !== this.token) {
          this.releaseHtmlAudio();
          return { ok: true };
        }
        if (maxSeconds > 0) {
          this.maxTimer = window.setTimeout(() => {
            if (token === this.token) this.stop();
          }, maxSeconds * 1000);
        }
        return { ok: true };
      } catch {
        this.releaseHtmlAudio();
        return {
          ok: false,
          error: 'تعذر تشغيل هذا الملف الصوتي؛ قد تكون الصيغة غير مدعومة على هذا الجهاز.',
        };
      }
    }

    if (nativeAlarmBridge.isNativeAndroid()) {
      const res = await nativeAlarmBridge.playNativeUriAudio({
        uri,
        loop,
        gradualFadeSeconds: 0,
        maxDurationSeconds: maxSeconds,
        volume: vol,
      });
      if (token !== this.token) {
        // أُلغي أثناء الانتظار: لا نترك صوتاً يعمل بلا مالك
        nativeAlarmBridge.stopNativeUriAudio();
        return { ok: true };
      }
      if (!res.playing) {
        return { ok: false, error: 'تعذر فتح ملف الصوت المحفوظ. قد يكون الملف مفقوداً.' };
      }
      return { ok: true };
    }

    return { ok: false, error: 'تعذر تشغيل مسار الملف الصوتي في هذه البيئة.' };
  }

  // ───────────────────────── رنين انتهاء الاستراحة ─────────────────────────
  public startRestExpiredLoop(opts: RestAlarmOptions) {
    this.ttsText = opts.ttsText; // يتحدّث بدون إعادة تشغيل الرنين

    const key = [
      opts.source,
      opts.sound,
      opts.customUri || '',
      opts.customSongId || '',
      opts.volume,
      opts.vibrate,
    ].join('|');

    // نفس الرنين يعمل الآن بنفس الإعدادات → لا نبدأ نسخة ثانية فوقه
    if (this.isPlaying && this.activeKey === key) return;

    this.stop();
    const token = this.token;
    this.isPlaying = true;
    this.activeKey = key;

    if (opts.vibrate) {
      this.vibrateOnce();
      this.vibTimer = window.setInterval(() => this.vibrateOnce(), 2800);
    }

    if (opts.source === 'app_tone') {
      this.startSynthLoop(opts.sound, opts.volume, token);
    } else {
      void this.startFileLoop(opts, token);
    }
  }

  private startSynthLoop(sound: SoundType, volume: number, token: number) {
    const master = this.createMaster(volume);
    const ctx = this.ctx as AudioContext;
    const periodMs = loopSeconds(sound) * 1000;
    let cycle = 0;

    const schedule = (delayMs: number) => {
      if (this.loopTimer !== null) clearTimeout(this.loopTimer);
      this.loopTimer = window.setTimeout(run, delayMs);
    };

    const run = () => {
      if (token !== this.token) return;

      if (ctx.state !== 'running') {
        // لا نجدول نوتات والسياق متوقف حتى لا تتراكم وتنفجر دفعة واحدة
        ctx.resume().catch(() => {});
        schedule(400);
        return;
      }

      const shouldSpeak = Boolean(this.ttsText) && cycle % 4 === 1;
      cycle++;

      if (shouldSpeak && this.ttsText) {
        // دورة نطق: لا نغمة فيها، ثم نكمل بعد انتهاء النطق
        schedule(7000); // احتياط إذا لم يصدر حدث الانتهاء
        this.speak(this.ttsText, volume, () => {
          if (token === this.token) schedule(700);
        });
        return;
      }

      schedulePattern(ctx, master, sound, ctx.currentTime + 0.02);
      schedule(periodMs);
    };

    run();
  }

  private async startFileLoop(opts: RestAlarmOptions, token: number) {
    // النطق أولاً (إن وُجد) ثم الأغنية، حتى لا يتداخل الصوتان
    if (this.ttsText) {
      await new Promise<void>((resolve) => {
        const fallback = window.setTimeout(resolve, 6000);
        this.speak(this.ttsText as string, opts.volume, () => {
          clearTimeout(fallback);
          resolve();
        });
      });
      if (token !== this.token) return;
    }

    let uri: string | undefined;
    let songId: string | undefined;
    if (opts.source === 'phone_ringtone') {
      uri = opts.customUri;
    } else if (opts.source === 'my_song') {
      const songs = getImportedSongs();
      const song =
        songs.find((s) => s.id === opts.customSongId) ||
        songs.find((s) => s.uri === opts.customUri);
      uri = song?.uri;
      songId = song?.id;
    }

    let ok = false;
    if (uri) {
      const res = await this.playFileSource(uri, songId, true, 0, opts.volume, token);
      if (token !== this.token) return;
      ok = res.ok;
    }

    if (!ok) {
      // الملف مفقود أو لا يعمل: نرجع لنغمة مدمجة بدل الصمت (ومصدر واحد فقط)
      this.startSynthLoop(opts.sound || DEFAULT_TONE, opts.volume, token);
    }
  }

  // ───────────────────────── نغمة قصيرة للتنبيهات الخفيفة ─────────────────────────
  public playStepCompleteChime() {
    if (this.isPlaying) return; // لا نضيف صوتاً فوق رنين انتهاء استراحة
    const ctx = this.initContext();
    const now = ctx.currentTime;
    const blip = (freq: number, start: number, dur: number, vol: number) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, start);
      gain.gain.setValueAtTime(0.001, start);
      gain.gain.exponentialRampToValueAtTime(Math.max(0.01, vol), start + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + dur);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(start);
      osc.stop(start + dur + 0.05);
    };
    blip(528, now, 0.35, 0.2);
    blip(660, now + 0.15, 0.45, 0.25);
  }
}

export const soundEngine = new AlarmAudioEngine();
