/** Durable event audit log for employee rest actions. */
export const REST_EVENTS_STORAGE_KEY = 'miqat_rest_events_v1';

export type RestEventType =
  | 'start_rest'
  | 'return_rest'
  | 'undo_return'
  | 'extend_rest'
  | 'pause_rest'
  | 'resume_rest'
  | 'cancel_rest'
  | 'delete_employee'
  | 'restore_employee'
  | 'add_employee'
  | 'reset_employee'
  | 'restore_reset'
  | 'new_day'
  | 'notification_schedule_failed'
  | 'pin_employee'
  | 'unpin_employee'
  | 'onboarding_completed'
  | 'permissions_opened'
  | 'action_sound'
  | 'balance_change';

export interface RestEventRecord {
  id: string;
  type: RestEventType;
  timestampIso: string;
  employeeId?: string;
  employeeName?: string;
  message: string;
  delaySeconds?: number;
  relatedLogId?: string;
}

export function loadRestEvents(): RestEventRecord[] {
  try {
    const raw = localStorage.getItem(REST_EVENTS_STORAGE_KEY);
    const parsed: unknown = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item): item is RestEventRecord => Boolean(
      item && typeof item === 'object' && typeof item.id === 'string' &&
      typeof item.type === 'string' && typeof item.timestampIso === 'string' &&
      typeof item.message === 'string'
    ));
  } catch {
    return [];
  }
}

export function createRestEvent(
  event: Omit<RestEventRecord, 'id' | 'timestampIso'> & { timestampMs?: number }
): RestEventRecord {
  const { timestampMs, ...data } = event;
  return {
    ...data,
    id: `evt-${timestampMs ?? Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    timestampIso: new Date(timestampMs ?? Date.now()).toISOString(),
  };
}
