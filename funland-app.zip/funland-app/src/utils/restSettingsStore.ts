import type { RestSettings } from '../types';

export const REST_SETTINGS_KEY = 'miqat_rest_settings_v1';
export const REST_SETTINGS_EVENT = 'funland-rest-settings-patch';

export const REST_SETTINGS_DEFAULTS: RestSettings = {
  dayResetHour: 5,
  dayResetMinute: 0,
  testModeMinuteAsSecond: false,
  wakeLockEnabled: true,
  maxConcurrentRests: 2,
  enableVoiceTTS: true,
  enableVibration: true,
  alarmSound: 'classic_pulse',
  alarmSoundSource: 'app_tone',
  alarmVolume: 0.85,
  enablePhase2Extras: true,
  notifyOnRestEnd: true,
  notifyBeforeRestEnd: true,
  restEndPreAlertMinutes: 5,
  notifyOnOvertime: true,
  overtimeAlertAfterMinutes: 5,
  fontScale: 'normal',
  primaryColor: '#2F80ED',
  speechLanguage: 'ar-SA',
  speechRate: 1,
  enableActionSound: true,
};

export function loadRestSettings(): RestSettings {
  try {
    const saved = localStorage.getItem(REST_SETTINGS_KEY);
    return saved ? { ...REST_SETTINGS_DEFAULTS, ...JSON.parse(saved) } : REST_SETTINGS_DEFAULTS;
  } catch {
    return REST_SETTINGS_DEFAULTS;
  }
}

/** يحفظ تغيير إعدادات الاستراحات ويُبلغ EmployeeRestManager (المركّب دائماً) ليتحدّث فوراً. */
export function patchRestSettings(patch: Partial<RestSettings>): RestSettings {
  const next = { ...loadRestSettings(), ...patch };
  try {
    localStorage.setItem(REST_SETTINGS_KEY, JSON.stringify(next));
  } catch {}
  window.dispatchEvent(new CustomEvent(REST_SETTINGS_EVENT, { detail: patch }));
  return next;
}
