import { nativeAlarmBridge } from './nativeAlarmBridge';

/**
 * يرسل نصاً إلى واتساب مباشرة.
 * - على أندرويد: يفتح واتساب (أو واتساب للأعمال) مباشرة بدون قائمة المشاركة.
 * - على المتصفح: يفتح رابط wa.me.
 * يرجع false إذا تعذّر (مثلاً واتساب غير مثبت) ليستخدم المستدعي بديلاً.
 */
export async function shareTextToWhatsApp(text: string): Promise<boolean> {
  if (await nativeAlarmBridge.shareTextToWhatsApp(text)) return true;
  if (nativeAlarmBridge.isNativeAndroid()) return false;
  try {
    window.open('https://wa.me/?text=' + encodeURIComponent(text), '_blank');
    return true;
  } catch {
    return false;
  }
}
