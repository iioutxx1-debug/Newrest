import type { SoundType } from '../types';

/**
 * مكتبة النغمات المدمجة.
 * كل النغمات مُولَّدة برمجياً (Web Audio) ولا تحتاج ملفات صوتية، ومكتوبة هنا كبيانات
 * (نوتات + أزمنة). وهي أصلية من تأليف التطبيق ومكتوبة بأسلوب يشبه نغمات الهواتف المعروفة،
 * وليست نسخاً من تسجيلات أو ألحان محمية لأي شركة.
 */

export interface ToneNote {
  f: number; // التردد (Hz)
  at: number; // وقت البدء داخل النمط (ثانية)
  d: number; // المدة (ثانية)
  g: number; // الشدة النسبية 0..1
  w: OscillatorType;
  f2?: number; // تردد النهاية (انزلاق صوتي)
  am?: number; // تردد الارتعاش (Hz) لمحاكاة جرس الهاتف القديم
}

export interface ToneDef {
  id: SoundType;
  label: string;
  hint: string;
  group: 'phones' | 'app';
  notes: ToneNote[];
  gap: number; // صمت بعد انتهاء النمط قبل تكراره
}

const seq = (
  freqs: number[],
  step: number,
  d: number,
  g: number,
  w: OscillatorType,
  start = 0
): ToneNote[] => freqs.map((f, i) => ({ f, at: start + i * step, d, g, w }));

const TONES: ToneDef[] = [
  // ───────────── رنين هواتف مشهور (أسلوب مشابه، مُولَّد داخل التطبيق) ─────────────
  {
    id: 'classic_phone_bell',
    label: 'جرس الهاتف القديم',
    hint: 'رنّة هاتف أرضي كلاسيكية (رنّتان متتاليتان)',
    group: 'phones',
    gap: 1.4,
    notes: [
      { f: 1400, at: 0, d: 0.9, g: 0.9, w: 'sine', am: 22 },
      { f: 1750, at: 0, d: 0.9, g: 0.7, w: 'sine', am: 22 },
      { f: 1400, at: 1.15, d: 0.9, g: 0.9, w: 'sine', am: 22 },
      { f: 1750, at: 1.15, d: 0.9, g: 0.7, w: 'sine', am: 22 },
    ],
  },
  {
    id: 'waltz_classic',
    label: 'فالس كلاسيكي',
    hint: 'لحن فالس قصير بأسلوب نغمات الهواتف القديمة',
    group: 'phones',
    gap: 0.9,
    notes: [
      { f: 659.25, at: 0.0, d: 0.14, g: 0.8, w: 'triangle' },
      { f: 587.33, at: 0.14, d: 0.14, g: 0.8, w: 'triangle' },
      { f: 369.99, at: 0.28, d: 0.28, g: 0.8, w: 'triangle' },
      { f: 415.3, at: 0.56, d: 0.28, g: 0.8, w: 'triangle' },
      { f: 554.37, at: 0.84, d: 0.14, g: 0.8, w: 'triangle' },
      { f: 493.88, at: 0.98, d: 0.14, g: 0.8, w: 'triangle' },
      { f: 293.66, at: 1.12, d: 0.28, g: 0.8, w: 'triangle' },
      { f: 329.63, at: 1.4, d: 0.28, g: 0.8, w: 'triangle' },
      { f: 493.88, at: 1.68, d: 0.14, g: 0.8, w: 'triangle' },
      { f: 440.0, at: 1.82, d: 0.14, g: 0.8, w: 'triangle' },
      { f: 277.18, at: 1.96, d: 0.28, g: 0.8, w: 'triangle' },
      { f: 329.63, at: 2.24, d: 0.28, g: 0.8, w: 'triangle' },
      { f: 440.0, at: 2.52, d: 0.7, g: 0.85, w: 'triangle' },
    ],
  },
  {
    id: 'marimba_soft',
    label: 'ماريمبا ناعمة',
    hint: 'نغمات ماريمبا صاعدة ونازلة، دافئة وواضحة',
    group: 'phones',
    gap: 0.9,
    notes: [
      ...seq([523.25, 659.25, 783.99, 1046.5, 783.99, 659.25, 523.25, 659.25], 0.17, 0.4, 0.8, 'triangle'),
      ...seq([1046.5, 1318.5, 1568, 2093, 1568, 1318.5, 1046.5, 1318.5], 0.17, 0.2, 0.22, 'sine'),
    ],
  },
  {
    id: 'digital_alarm',
    label: 'منبّه رقمي',
    hint: 'أربع صفرات رقمية سريعة ثم توقف قصير',
    group: 'phones',
    gap: 0.6,
    notes: [
      ...seq([2200, 2200, 2200, 2200], 0.15, 0.08, 0.55, 'square'),
      ...seq([2200, 2200, 2200, 2200], 0.15, 0.08, 0.55, 'square', 0.9),
    ],
  },
  {
    id: 'sms_bubble',
    label: 'فقاعة رسالة',
    hint: 'نغمتان قصيرتان خفيفتان مثل تنبيه الرسائل',
    group: 'phones',
    gap: 1.2,
    notes: [
      { f: 880, at: 0, d: 0.14, g: 0.8, w: 'sine' },
      { f: 1318.5, at: 0.13, d: 0.3, g: 0.8, w: 'sine' },
      { f: 880, at: 0.75, d: 0.14, g: 0.8, w: 'sine' },
      { f: 1318.5, at: 0.88, d: 0.3, g: 0.8, w: 'sine' },
    ],
  },
  {
    id: 'radar_pulse',
    label: 'رادار',
    hint: 'نبضات سونار هادئة متباعدة',
    group: 'phones',
    gap: 0.6,
    notes: [
      { f: 1100, f2: 900, at: 0, d: 1.0, g: 0.9, w: 'sine' },
      { f: 2200, f2: 1800, at: 0, d: 0.5, g: 0.25, w: 'sine' },
      { f: 1100, f2: 900, at: 1.1, d: 1.0, g: 0.9, w: 'sine' },
      { f: 2200, f2: 1800, at: 1.1, d: 0.5, g: 0.25, w: 'sine' },
    ],
  },
  {
    id: 'ascending_bells',
    label: 'أجراس صاعدة',
    hint: 'أجراس لامعة تصعد درجةً درجة',
    group: 'phones',
    gap: 0.8,
    notes: [
      ...seq([523.25, 659.25, 783.99, 1046.5, 1318.5], 0.22, 1.1, 0.75, 'sine'),
      ...seq([1255.8, 1582.2, 1881.6, 2511.6, 3164.4], 0.22, 0.5, 0.2, 'sine'),
    ],
  },
  {
    id: 'retro_arcade',
    label: 'ألعاب كلاسيكية',
    hint: 'نغمات قصيرة بأسلوب ألعاب الأركيد القديمة',
    group: 'phones',
    gap: 0.8,
    notes: seq([523.25, 659.25, 783.99, 1046.5, 783.99, 1046.5, 1318.5], 0.1, 0.1, 0.6, 'square'),
  },
  {
    id: 'urgent_siren',
    label: 'صفّارة تنبيه',
    hint: 'نغمة صاعدة هابطة قوية، مناسبة للأماكن الصاخبة',
    group: 'phones',
    gap: 0.5,
    notes: [
      { f: 600, f2: 1000, at: 0.0, d: 0.6, g: 0.8, w: 'triangle' },
      { f: 1000, f2: 600, at: 0.6, d: 0.6, g: 0.8, w: 'triangle' },
      { f: 600, f2: 1000, at: 1.2, d: 0.6, g: 0.8, w: 'triangle' },
      { f: 1000, f2: 600, at: 1.8, d: 0.6, g: 0.8, w: 'triangle' },
    ],
  },
  {
    id: 'harp_glide',
    label: 'قيثارة',
    hint: 'مرور سريع على أوتار قيثارة',
    group: 'phones',
    gap: 1.0,
    notes: seq([392, 440, 523.25, 587.33, 659.25, 783.99, 880, 1046.5], 0.09, 0.8, 0.55, 'sine'),
  },

  // ───────────── نغمات التطبيق الأصلية ─────────────
  {
    id: 'classic_pulse',
    label: 'نبضات كلاسيكية',
    hint: 'أربع نبضات حادة، الافتراضية',
    group: 'app',
    gap: 0.9,
    notes: seq([800, 800, 800, 800], 0.22, 0.12, 1, 'square'),
  },
  {
    id: 'fajr_adhan_tone',
    label: 'نغمة الفجر',
    hint: 'مقام هادئ يشبه ابتداء الأذان',
    group: 'app',
    gap: 0.9,
    notes: seq([293.66, 329.63, 370.0, 440.0, 370.0, 329.63, 293.66], 0.32, 0.75, 0.85, 'sine'),
  },
  {
    id: 'makkah_tone',
    label: 'نغمة مكة',
    hint: 'نغمات صاعدة هابطة بصوت دافئ',
    group: 'app',
    gap: 0.9,
    notes: seq([329.63, 392.0, 440.0, 493.88, 440.0, 392.0], 0.34, 0.85, 0.85, 'triangle'),
  },
  {
    id: 'calm_piano',
    label: 'بيانو هادئ',
    hint: 'أربيجيو بيانو بسيط',
    group: 'app',
    gap: 0.9,
    notes: seq([261.63, 329.63, 392.0, 523.25, 392.0, 329.63], 0.26, 0.9, 0.75, 'sine'),
  },
  {
    id: 'dawn_chimes',
    label: 'أجراس الفجر',
    hint: 'أجراس خفيفة صاعدة',
    group: 'app',
    gap: 0.9,
    notes: seq([440, 493.88, 554.37, 659.25, 880], 0.28, 0.9, 0.8, 'sine'),
  },
  {
    id: 'nature_birds',
    label: 'زقزقة عصافير',
    hint: 'تغريد عصافير سريع',
    group: 'app',
    gap: 1.1,
    notes: seq([1200, 1450, 1320, 1680, 1500], 0.18, 0.22, 0.6, 'triangle'),
  },
  {
    id: 'zen_bowl',
    label: 'وعاء زِن',
    hint: 'رنين وعاء معدني طويل وهادئ',
    group: 'app',
    gap: 0.8,
    notes: [
      { f: 256, at: 0, d: 2.1, g: 1, w: 'sine' },
      { f: 512, at: 0.05, d: 1.8, g: 0.45, w: 'sine' },
      { f: 768, at: 0.1, d: 1.4, g: 0.2, w: 'sine' },
    ],
  },
];

const TONE_MAP = new Map<SoundType, ToneDef>(TONES.map((t) => [t.id, t]));

export const DEFAULT_TONE: SoundType = 'classic_pulse';

export function getToneDef(sound: SoundType): ToneDef {
  return TONE_MAP.get(sound) || (TONE_MAP.get(DEFAULT_TONE) as ToneDef);
}

export function getToneGroups(): { id: 'phones' | 'app'; title: string; tones: ToneDef[] }[] {
  return [
    {
      id: 'phones',
      title: 'نغمات رنين مشهورة بالهواتف',
      tones: TONES.filter((t) => t.group === 'phones'),
    },
    {
      id: 'app',
      title: 'نغمات التطبيق',
      tones: TONES.filter((t) => t.group === 'app'),
    },
  ];
}

/** مدة النمط الواحد بالثواني (بدون الصمت الفاصل). */
export function patternSeconds(sound: SoundType): number {
  const def = getToneDef(sound);
  return def.notes.reduce((m, n) => Math.max(m, n.at + n.d), 0) + 0.05;
}

/** دورة التكرار الكاملة: النمط + الصمت. تضمن ألّا يبدأ نمط جديد قبل انتهاء السابق. */
export function loopSeconds(sound: SoundType): number {
  return patternSeconds(sound) + getToneDef(sound).gap;
}

/**
 * يجدول نمط النغمة على سياق صوتي ويوجّه الخرج إلى `dest`.
 * الشدة الكلية تتحكم بها عقدة `dest` (gain رئيسي) وليس النوتات نفسها.
 */
export function schedulePattern(
  ctx: BaseAudioContext,
  dest: AudioNode,
  sound: SoundType,
  t0: number
): void {
  const def = getToneDef(sound);
  for (const n of def.notes) {
    const start = t0 + n.at;
    const end = start + n.d;

    const osc = ctx.createOscillator();
    osc.type = n.w;
    osc.frequency.setValueAtTime(n.f, start);
    if (n.f2) {
      osc.frequency.exponentialRampToValueAtTime(n.f2, end);
    }

    const env = ctx.createGain();
    env.gain.setValueAtTime(0.001, start);
    env.gain.exponentialRampToValueAtTime(Math.max(0.01, n.g), start + Math.min(0.04, n.d / 2));
    env.gain.exponentialRampToValueAtTime(0.0001, end);

    osc.connect(env);

    let out: AudioNode = env;
    if (n.am) {
      const trem = ctx.createGain();
      trem.gain.value = 0.5;
      const lfo = ctx.createOscillator();
      lfo.frequency.value = n.am;
      const lfoDepth = ctx.createGain();
      lfoDepth.gain.value = 0.5;
      lfo.connect(lfoDepth);
      lfoDepth.connect(trem.gain);
      env.connect(trem);
      out = trem;
      lfo.start(start);
      lfo.stop(end + 0.05);
    }
    out.connect(dest);

    osc.start(start);
    osc.stop(end + 0.05);
  }
}
