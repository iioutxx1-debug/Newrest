/**
 * ذاكرة الجداول (Funland)
 * -----------------------
 * صفحة الجداول تحفظ آخر جدول + سجل الجداول بالتاريخ في localStorage (المفاتيح fl_*).
 * localStorage يُمسح عند حذف التطبيق، لذلك نحتفظ بنسخة احتياطية تلقائية خارج التطبيق
 * في مجلد المستندات: Documents/Funland/schedules-backup.json
 * وعند أول فتح بعد إعادة التثبيت (وlocalStorage فارغ) نسترجعها قبل تحميل صفحة الجداول.
 */
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

const PREFIX = 'fl_';
const FORMAT = 'funland-schedules-backup';
const DIR = 'Funland';
const FILE_MAIN = `${DIR}/schedules-backup.json`;
const FILE_ALT = `${DIR}/schedules-backup-2.json`; // احتياطي إذا تعذّرت الكتابة فوق الملف الأول
const LAST_SAVED_KEY = 'miqat_schedule_backup_last_v1'; // خارج البادئة fl_ عمداً

type DataMap = Record<string, string>;
interface Payload {
  format: string;
  v: number;
  savedAt: string;
  data: DataMap;
}

const isNative = () => {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
};

/** كل مفاتيح الجداول الموجودة حالياً في localStorage (قيم نصية كما هي) */
function collect(): DataMap {
  const out: DataMap = {};
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(PREFIX)) {
        const v = localStorage.getItem(k);
        if (v != null) out[k] = v;
      }
    }
  } catch {}
  return out;
}

export function hasScheduleData(): boolean {
  return Object.keys(collect()).length > 0;
}

function parsePayload(text: string): Payload | null {
  try {
    const p = JSON.parse(text);
    if (!p || p.format !== FORMAT || typeof p.data !== 'object' || !p.data) return null;
    const data: DataMap = {};
    for (const [k, v] of Object.entries(p.data)) {
      if (k.startsWith(PREFIX) && typeof v === 'string') data[k] = v;
    }
    if (!Object.keys(data).length) return null;
    return { format: FORMAT, v: Number(p.v) || 1, savedAt: String(p.savedAt || ''), data };
  } catch {
    return null;
  }
}

function applyData(data: DataMap) {
  Object.entries(data).forEach(([k, v]) => {
    try {
      localStorage.setItem(k, v);
    } catch {}
  });
}

function buildText(data: DataMap): string {
  const payload: Payload = { format: FORMAT, v: 1, savedAt: new Date().toISOString(), data };
  return JSON.stringify(payload);
}

async function readFileText(path: string): Promise<string | null> {
  try {
    const r = await Filesystem.readFile({
      path,
      directory: Directory.Documents,
      encoding: Encoding.UTF8,
    });
    return typeof r.data === 'string' ? r.data : null;
  } catch {
    return null;
  }
}

async function writeFileText(path: string, text: string): Promise<boolean> {
  try {
    await Filesystem.writeFile({
      path,
      data: text,
      directory: Directory.Documents,
      encoding: Encoding.UTF8,
      recursive: true,
    });
    return true;
  } catch {
    return false;
  }
}

/** أحدث نسخة صالحة من الملفين */
async function readBestBackup(): Promise<Payload | null> {
  if (!isNative()) return null;
  const texts = await Promise.all([readFileText(FILE_MAIN), readFileText(FILE_ALT)]);
  const valid = texts
    .map((t) => (t ? parsePayload(t) : null))
    .filter((p): p is Payload => !!p)
    .sort((a, b) => b.savedAt.localeCompare(a.savedAt));
  return valid[0] ?? null;
}

export type RestoreResult = 'kept' | 'restored' | 'empty';

/**
 * يُستدعى مرة عند تشغيل التطبيق وقبل تحميل صفحة الجداول.
 * - لو في بيانات جداول حالياً: لا نلمسها.
 * - لو فاضي وفي نسخة احتياطية: نسترجعها.
 */
export async function restoreIfEmpty(): Promise<RestoreResult> {
  if (hasScheduleData()) return 'kept';
  const best = await readBestBackup();
  if (!best) return 'empty';
  applyData(best.data);
  try {
    localStorage.setItem(LAST_SAVED_KEY, best.savedAt);
  } catch {}
  return 'restored';
}

/** استرجاع يدوي من نص ملف JSON (يستبدل بيانات الجداول الحالية) */
export function restoreFromText(text: string): boolean {
  const p = parsePayload(text);
  if (!p) return false;
  // نمسح مفاتيح الجداول القديمة أولاً حتى لا يبقى شيء من نسخة أخرى
  Object.keys(collect()).forEach((k) => {
    try {
      localStorage.removeItem(k);
    } catch {}
  });
  applyData(p.data);
  try {
    localStorage.setItem(LAST_SAVED_KEY, p.savedAt);
  } catch {}
  return true;
}

export function getLastBackupTime(): string | null {
  try {
    return localStorage.getItem(LAST_SAVED_KEY);
  } catch {
    return null;
  }
}

let lastHash = '';
let writing = false;

async function backupNow(force = false): Promise<boolean> {
  if (!isNative() || writing) return false;
  const data = collect();
  if (!Object.keys(data).length) return false; // لا نكتب نسخة فارغة فوق نسخة جيدة
  const hash = JSON.stringify(data);
  if (!force && hash === lastHash) return false;
  writing = true;
  try {
    const text = buildText(data);
    const ok = (await writeFileText(FILE_MAIN, text)) || (await writeFileText(FILE_ALT, text));
    if (ok) {
      lastHash = hash;
      try {
        localStorage.setItem(LAST_SAVED_KEY, new Date().toISOString());
      } catch {}
    }
    return ok;
  } finally {
    writing = false;
  }
}

/** يراقب تغيّر بيانات الجداول (صفحة الجداول داخل iframe بنفس الأصل) ويحفظ نسخة تلقائياً */
export function startAutoBackup(): () => void {
  if (!isNative()) return () => {};
  let timer: ReturnType<typeof setTimeout> | null = null;
  const schedule = () => {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => void backupNow(), 800);
  };
  const onStorage = (e: StorageEvent) => {
    if (!e.key || e.key.startsWith(PREFIX)) schedule();
  };
  const onHide = () => {
    if (document.visibilityState === 'hidden') void backupNow();
  };
  window.addEventListener('storage', onStorage);
  document.addEventListener('visibilitychange', onHide);
  window.addEventListener('pagehide', onHide);
  const poll = setInterval(() => void backupNow(), 4000); // شبكة أمان لو لم يصل حدث storage
  void backupNow();
  return () => {
    window.removeEventListener('storage', onStorage);
    document.removeEventListener('visibilitychange', onHide);
    window.removeEventListener('pagehide', onHide);
    clearInterval(poll);
    if (timer) clearTimeout(timer);
  };
}

/** يحفظ نسخة ثم يفتح قائمة المشاركة (واتساب/درايف...) لنسخة خارجية مضمونة */
export async function shareBackup(): Promise<boolean> {
  const data = collect();
  if (!Object.keys(data).length) return false;
  const text = buildText(data);
  const name = `funland-schedules-${new Date().toISOString().slice(0, 10)}.json`;
  if (!isNative()) {
    const url = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    return true;
  }
  const w = await Filesystem.writeFile({
    path: name,
    data: text,
    directory: Directory.Cache,
    encoding: Encoding.UTF8,
  });
  await Share.share({ title: name, files: [w.uri], dialogTitle: 'حفظ نسخة احتياطية للجداول' });
  return true;
}

/** عند إعادة ضبط المصنع: نحذف نسخ الملفات أيضاً وإلا ستُسترجع البيانات القديمة */
export async function deleteBackupFiles(): Promise<void> {
  if (!isNative()) return;
  for (const path of [FILE_MAIN, FILE_ALT]) {
    try {
      await Filesystem.deleteFile({ path, directory: Directory.Documents });
    } catch {}
  }
}
