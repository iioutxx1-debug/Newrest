/**
 * تصدير الجداول (حفظ PNG/PDF ومشاركة واتساب)
 * ------------------------------------------
 * صفحة الجداول تعمل داخل iframe، وردّ أندرويد على استدعاءات إضافات Capacitor
 * لا يصل إلى الـ iframe (فيبقى "جاري التجهيز..." معلّقاً). لذلك الصفحة ترسل الملف
 * إلى هنا (النافذة الأم) عبر postMessage، ونحن ننفّذ الحفظ/المشاركة ونرد بالنتيجة.
 */
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { nativeAlarmBridge } from './nativeAlarmBridge';

interface ExportMsg {
  type: 'funland-export';
  id: string;
  kind: 'save' | 'whatsapp';
  name: string;
  mime: string;
  b64: string;
}

const errText = (e: unknown) => String((e as { message?: string })?.message ?? e ?? '');
const isCancel = (e: unknown) => errText(e).toLowerCase().includes('cancel');

async function handle(msg: ExportMsg): Promise<void> {
  const w = await Filesystem.writeFile({
    path: msg.name,
    data: msg.b64,
    directory: Directory.Cache,
  });

  if (msg.kind === 'whatsapp') {
    try {
      await nativeAlarmBridge.shareFileToApp('com.whatsapp', w.uri, msg.mime || 'image/png');
      return;
    } catch (e) {
      if (errText(e).includes('app_not_installed')) {
        throw new Error('تطبيق واتساب غير مثبت على هذا الجهاز');
      }
      // أي خطأ آخر: نرجع لقائمة المشاركة العادية
    }
  }

  try {
    await Share.share({ title: msg.name, files: [w.uri], dialogTitle: 'حفظ / مشاركة الجدول' });
  } catch (e) {
    if (isCancel(e)) throw Object.assign(new Error('declined'), { code: 'declined' });
    // حل أخير: حفظ في مجلد المستندات
    await Filesystem.writeFile({
      path: `Funland/${msg.name}`,
      data: msg.b64,
      directory: Directory.Documents,
      recursive: true,
    });
    throw new Error(`تم حفظ الملف في المستندات: Funland/${msg.name}`);
  }
}

/** يبدأ الاستماع لطلبات التصدير القادمة من iframe الجداول. يرجع دالة لإيقافه. */
export function startScheduleExportListener(getFrameWindow: () => Window | null | undefined): () => void {
  const onMessage = (ev: MessageEvent) => {
    const d = ev.data as ExportMsg | undefined;
    if (!d || d.type !== 'funland-export' || typeof d.id !== 'string') return;
    const frame = getFrameWindow();
    if (!frame || ev.source !== frame) return; // فقط من صفحة الجداول

    const reply = (payload: Record<string, unknown>) => {
      try {
        frame.postMessage({ id: d.id, ...payload }, '*');
      } catch {}
    };
    reply({ type: 'funland-export-ack' });

    if (!Capacitor.isNativePlatform()) {
      reply({ type: 'funland-export-result', ok: false, error: 'التصدير متاح داخل التطبيق فقط' });
      return;
    }

    handle(d)
      .then(() => reply({ type: 'funland-export-result', ok: true }))
      .catch((e: { code?: string; message?: string }) =>
        reply({
          type: 'funland-export-result',
          ok: false,
          code: e?.code,
          error: errText(e) || 'تعذر الحفظ',
        })
      );
  };
  window.addEventListener('message', onMessage);
  return () => window.removeEventListener('message', onMessage);
}
