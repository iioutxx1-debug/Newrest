import type { RestSettings } from '../types';
import { nativeAlarmBridge } from './nativeAlarmBridge';

let lastSyncedKey = '';

/**
 * يُبلغ جانب أندرويد بالنغمة التي يشغّلها النظام عند انتهاء استراحة والتطبيق في الخلفية/مغلق.
 * ملاحظة: النظام لا يستطيع قراءة ملفات خاصة بالتطبيق، لذلك يُدعم هنا فقط اختيار «نغمة الهاتف».
 * إذا كانت النغمة المختارة من نغمات التطبيق أو «أغنياتي» يرنّ النظام بمنبّه الهاتف الافتراضي في
 * الخلفية، وبمجرد فتح التطبيق يتولى التطبيق تشغيل النغمة المختارة وحده.
 */
export function syncRestSoundToNative(
  s: Pick<RestSettings, 'alarmSoundSource' | 'alarmCustomUri' | 'alarmVolume'>
): void {
  if (!nativeAlarmBridge.isNativeAndroid()) return;
  const uri = s.alarmSoundSource === 'phone_ringtone' ? s.alarmCustomUri : undefined;
  const key = `${uri || ''}|${s.alarmVolume}`;
  if (key === lastSyncedKey) return;
  lastSyncedKey = key;
  void nativeAlarmBridge.setRestAlarmSound(uri, s.alarmVolume);
}
