import React, { useMemo, useState } from 'react';
import { Search, Filter, CalendarDays, Clock3 } from 'lucide-react';
import type { RestEventRecord, RestEventType } from '../utils/restEventLog';

interface Props {
  events: RestEventRecord[];
}

const EVENT_LABELS: Record<RestEventType, string> = {
  start_rest: 'بدء استراحة',
  return_rest: 'تسجيل عودة',
  undo_return: 'تراجع عن العودة',
  extend_rest: 'تمديد استراحة',
  pause_rest: 'إيقاف مؤقت',
  resume_rest: 'استئناف استراحة',
  cancel_rest: 'إلغاء استراحة',
  delete_employee: 'حذف موظف',
  restore_employee: 'استرجاع موظف',
  add_employee: 'إضافة موظف',
  reset_employee: 'تصفير سجل موظف',
  restore_reset: 'استرجاع سجل موظف',
  new_day: 'بدء يوم جديد',
  notification_schedule_failed: 'فشل جدولة تنبيه',
  pin_employee: 'تثبيت موظف',
  unpin_employee: 'إلغاء تثبيت موظف',
  onboarding_completed: 'إكمال التعريف',
  permissions_opened: 'فتح إعدادات الصلاحيات',
  action_sound: 'صوت تأكيد',
  balance_change: 'تغيير الرصيد',
};

const asDate = (iso: string) => {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? null : d;
};

export const RestEventLogView: React.FC<Props> = ({ events }) => {
  const [search, setSearch] = useState('');
  const [type, setType] = useState('all');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');

  const filtered = useMemo(() => events.filter((event) => {
    const name = `${event.employeeName ?? ''} ${event.message}`.toLocaleLowerCase('ar');
    const date = asDate(event.timestampIso);
    const day = date ? `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}` : '';
    return (!search.trim() || name.includes(search.trim().toLocaleLowerCase('ar')))
      && (type === 'all' || event.type === type)
      && (!from || day >= from)
      && (!to || day <= to);
  }).sort((a, b) => b.timestampIso.localeCompare(a.timestampIso)), [events, search, type, from, to]);

  const totalDelaySeconds = filtered
    .filter((event) => event.type === 'return_rest')
    .reduce((sum, event) => sum + Math.max(0, event.delaySeconds ?? 0), 0);
  const eventTypes = Array.from(new Set(events.map((event) => event.type)));
  const delayMinutes = Math.floor(totalDelaySeconds / 60);
  const delayLabel = delayMinutes > 0
    ? `${delayMinutes} دقيقة${totalDelaySeconds % 60 ? ` و${totalDelaySeconds % 60} ثانية` : ''}`
    : `${totalDelaySeconds} ثانية`;

  return (
    <section className="space-y-4" dir="rtl">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
        <label className="sm-input min-h-[42px] px-3 flex items-center gap-2">
          <Search className="w-4 h-4 text-slate-500 shrink-0" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ابحث باسم الموظف أو الحدث" className="w-full bg-transparent outline-none text-sm" />
        </label>
        <label className="sm-input min-h-[42px] px-3 flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-500 shrink-0" />
          <select aria-label="نوع الحدث" value={type} onChange={(e) => setType(e.target.value)} className="w-full bg-transparent outline-none text-sm">
            <option value="all">كل أنواع الأحداث</option>
            {eventTypes.map((item) => <option key={item} value={item}>{EVENT_LABELS[item] ?? item}</option>)}
          </select>
        </label>
        <label className="sm-input min-h-[42px] px-3 flex items-center gap-2">
          <CalendarDays className="w-4 h-4 text-slate-500 shrink-0" />
          <input aria-label="من تاريخ" type="date" value={from} max={to || undefined} onChange={(e) => setFrom(e.target.value)} className="w-full bg-transparent outline-none text-xs" />
        </label>
        <label className="sm-input min-h-[42px] px-3 flex items-center gap-2">
          <CalendarDays className="w-4 h-4 text-slate-500 shrink-0" />
          <input aria-label="إلى تاريخ" type="date" value={to} min={from || undefined} onChange={(e) => setTo(e.target.value)} className="w-full bg-transparent outline-none text-xs" />
        </label>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-slate-50 border border-slate-200 p-3 text-sm">
        <span className="font-bold">عدد الأحداث: {filtered.length}</span>
        <span className="font-bold text-rose-700">مجموع التأخير بالفترة: {delayLabel}</span>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-xl border border-dashed border-slate-300 p-8 text-center text-sm text-slate-500">لا توجد أحداث تطابق خيارات البحث.</div>
      ) : (
        <div className="space-y-2">
          {filtered.map((event) => {
            const date = asDate(event.timestampIso);
            return <article key={event.id} className="rounded-xl border border-slate-200 bg-white p-3 sm:p-4">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="font-bold text-sm text-slate-800">{EVENT_LABELS[event.type] ?? event.type}{event.employeeName ? ` — ${event.employeeName}` : ''}</div>
                  <p className="mt-1 text-xs leading-6 text-slate-600">{event.message}</p>
                </div>
                <span className="inline-flex items-center gap-1 rounded-lg bg-slate-100 px-2 py-1 text-[11px] text-slate-600 whitespace-nowrap">
                  <Clock3 className="h-3.5 w-3.5" />
                  {date ? date.toLocaleString('ar-IQ', { dateStyle: 'short', timeStyle: 'short' }) : 'وقت غير معروف'}
                </span>
              </div>
            </article>;
          })}
        </div>
      )}
    </section>
  );
};
