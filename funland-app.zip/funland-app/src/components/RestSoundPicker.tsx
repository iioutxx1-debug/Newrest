import React, { useEffect, useRef, useState } from 'react';
import { Play, Square, Check, Music, Smartphone, Trash2, Plus, Volume2 } from 'lucide-react';
import { ImportedSongItem, RestSettings, SoundSourceType, SoundType } from '../types';
import { soundEngine } from '../utils/soundEngine';
import { getToneGroups, patternSeconds, DEFAULT_TONE } from '../utils/toneLibrary';
import { nativeAlarmBridge } from '../utils/nativeAlarmBridge';
import {
  getImportedSongs,
  importSongFromDevice,
  deleteImportedSongFromLibrary,
  formatSecondsMMSS,
} from '../utils/audioLibraryStore';

interface RestSoundPickerProps {
  settings: RestSettings;
  onChange: (patch: Partial<RestSettings>) => void;
}

const TABS: { id: SoundSourceType; label: string }[] = [
  { id: 'app_tone', label: 'نغمات التطبيق' },
  { id: 'phone_ringtone', label: 'نغمة الهاتف' },
  { id: 'my_song', label: 'أغنياتي' },
];

export const RestSoundPicker: React.FC<RestSoundPickerProps> = ({ settings, onChange }) => {
  const activeSource: SoundSourceType = settings.alarmSoundSource || 'app_tone';
  const [tab, setTab] = useState<SoundSourceType>(activeSource);
  const [previewId, setPreviewId] = useState<string | null>(null);
  const [songs, setSongs] = useState<ImportedSongItem[]>(() => getImportedSongs());
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const previewResetRef = useRef<number | null>(null);
  const ownsPreviewRef = useRef(false);

  // عند إغلاق الشاشة نقطع المعاينة فقط (لا نقطع رنين تنبيه فعلي)
  useEffect(() => {
    return () => {
      if (previewResetRef.current !== null) clearTimeout(previewResetRef.current);
      if (ownsPreviewRef.current && !soundEngine.isAlarmRinging()) soundEngine.stop();
    };
  }, []);

  const armPreviewReset = (id: string, ms: number) => {
    if (previewResetRef.current !== null) clearTimeout(previewResetRef.current);
    previewResetRef.current = window.setTimeout(() => {
      setPreviewId((p) => (p === id ? null : p));
      ownsPreviewRef.current = false;
    }, ms);
  };

  const stopPreview = () => {
    if (previewResetRef.current !== null) clearTimeout(previewResetRef.current);
    if (!soundEngine.isAlarmRinging()) soundEngine.stop();
    ownsPreviewRef.current = false;
    setPreviewId(null);
  };

  const previewTone = (sound: SoundType) => {
    setMessage(null);
    if (previewId === `tone:${sound}`) {
      stopPreview();
      return;
    }
    if (soundEngine.isAlarmRinging()) {
      setMessage('هناك تنبيه فعلي يرنّ الآن. أوقفه أولاً ثم جرّب النغمات.');
      return;
    }
    soundEngine.playPreview(sound, settings.alarmVolume);
    ownsPreviewRef.current = true;
    setPreviewId(`tone:${sound}`);
    armPreviewReset(`tone:${sound}`, patternSeconds(sound) * 1000 + 250);
  };

  const selectTone = (sound: SoundType) => {
    onChange({ alarmSound: sound, alarmSoundSource: 'app_tone' });
    previewTone(sound);
  };

  const previewCustom = async (
    id: string,
    source: 'phone_ringtone' | 'my_song',
    uri: string | undefined,
    songId: string | undefined,
    maxMs: number
  ) => {
    setMessage(null);
    if (previewId === id) {
      stopPreview();
      return;
    }
    const res = await soundEngine.playCustomSourcePreview({
      soundSource: source,
      sound: settings.alarmSound || DEFAULT_TONE,
      customSoundUri: uri,
      customSongId: songId,
      volume: settings.alarmVolume,
    });
    if (!res.ok) {
      setMessage(res.error || 'تعذر تشغيل المعاينة.');
      return;
    }
    ownsPreviewRef.current = true;
    setPreviewId(id);
    armPreviewReset(id, maxMs);
  };

  const pickPhoneRingtone = async () => {
    setMessage(null);
    setBusy(true);
    try {
      const res = await nativeAlarmBridge.pickSystemAlarmRingtone(settings.alarmCustomUri);
      if (res.error) {
        setMessage(res.error);
      } else if (!res.cancelled && res.uri) {
        onChange({
          alarmSoundSource: 'phone_ringtone',
          alarmCustomUri: res.uri,
          alarmCustomTitle: res.title || 'نغمة من الهاتف',
        });
      }
    } finally {
      setBusy(false);
    }
  };

  const addSong = async () => {
    setMessage(null);
    setBusy(true);
    try {
      const res = await importSongFromDevice();
      if (res.error) {
        setMessage(res.error);
      } else if (!res.cancelled && res.song) {
        setSongs(getImportedSongs());
        onChange({ alarmSoundSource: 'my_song', alarmCustomSongId: res.song.id });
      }
    } finally {
      setBusy(false);
    }
  };

  const removeSong = async (song: ImportedSongItem) => {
    stopPreview();
    await deleteImportedSongFromLibrary(song.id);
    setSongs(getImportedSongs());
    if (activeSource === 'my_song' && settings.alarmCustomSongId === song.id) {
      onChange({ alarmSoundSource: 'app_tone', alarmCustomSongId: undefined });
    }
  };

  const rowBase =
    'flex items-center gap-2 p-2.5 rounded-xl border transition-colors cursor-pointer';
  const rowOn = 'bg-[#EBF3FE] border-[#2F80ED]';
  const rowOff = 'bg-white border-[#E6EDF5] hover:bg-[#F4F7FB]';

  const previewBtn = (isOn: boolean, onClick: () => void, label: string) => (
    <button
      type="button"
      aria-label={label}
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
      className="min-w-[38px] min-h-[38px] rounded-full bg-[#1B365D] text-white flex items-center justify-center cursor-pointer shrink-0"
    >
      {isOn ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4" />}
    </button>
  );

  return (
    <div className="p-4 rounded-2xl bg-[#F4F7FB] border border-[#E6EDF5] space-y-3.5">
      <div className="flex items-center gap-2">
        <Music className="w-4 h-4 text-[#2F80ED]" />
        <h4 className="text-sm font-extrabold text-[#172B4D]">نغمة انتهاء الاستراحة</h4>
      </div>

      {/* التبويبات */}
      <div className="grid grid-cols-3 gap-1.5">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={`min-h-[38px] rounded-xl text-xs font-bold cursor-pointer transition-colors ${
              tab === t.id
                ? 'bg-[#1B365D] text-white'
                : 'bg-white text-[#172B4D] border border-[#E6EDF5]'
            }`}
          >
            {t.label}
            {activeSource === t.id ? ' ✓' : ''}
          </button>
        ))}
      </div>

      {/* نغمات التطبيق */}
      {tab === 'app_tone' && (
        <div className="space-y-3">
          {getToneGroups().map((group) => (
            <div key={group.id} className="space-y-1.5">
              <span className="text-[11px] font-extrabold text-[#6B7C93] block">{group.title}</span>
              {group.tones.map((tone) => {
                const selected = activeSource === 'app_tone' && settings.alarmSound === tone.id;
                return (
                  <div
                    key={tone.id}
                    role="radio"
                    aria-checked={selected}
                    onClick={() => selectTone(tone.id)}
                    className={`${rowBase} ${selected ? rowOn : rowOff}`}
                  >
                    <span
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                        selected ? 'border-[#2F80ED] bg-[#2F80ED]' : 'border-[#CBD5E1]'
                      }`}
                    >
                      {selected && <Check className="w-3 h-3 text-white" />}
                    </span>
                    <div className="flex-1 min-w-0">
                      <span className="text-xs font-bold text-[#172B4D] block">{tone.label}</span>
                      <span className="text-[11px] text-[#6B7C93] block truncate">{tone.hint}</span>
                    </div>
                    {previewBtn(previewId === `tone:${tone.id}`, () => previewTone(tone.id), `تجربة ${tone.label}`)}
                  </div>
                );
              })}
            </div>
          ))}
          <p className="text-[11px] text-[#6B7C93] leading-relaxed">
            هذه النغمات مُولَّدة داخل التطبيق بأسلوب يشبه نغمات الهواتف المعروفة. وإذا أردت نغمة
            هاتفك الأصلية نفسها (مثل نغمة سامسونج أو آيفون المثبتة على جهازك) فاخترها من تبويب
            «نغمة الهاتف».
          </p>
        </div>
      )}

      {/* نغمة الهاتف */}
      {tab === 'phone_ringtone' && (
        <div className="space-y-2.5">
          {settings.alarmCustomUri ? (
            <div
              className={`${rowBase} ${activeSource === 'phone_ringtone' ? rowOn : rowOff}`}
              onClick={() => onChange({ alarmSoundSource: 'phone_ringtone' })}
            >
              <Smartphone className="w-4 h-4 text-[#2F80ED] shrink-0" />
              <div className="flex-1 min-w-0">
                <span className="text-xs font-bold text-[#172B4D] block truncate">
                  {settings.alarmCustomTitle || 'نغمة من الهاتف'}
                </span>
                <span className="text-[11px] text-[#6B7C93] block">
                  {activeSource === 'phone_ringtone' ? 'مُفعَّلة' : 'اضغط للتفعيل'}
                </span>
              </div>
              {previewBtn(
                previewId === 'phone',
                () => previewCustom('phone', 'phone_ringtone', settings.alarmCustomUri, undefined, 15000),
                'تجربة نغمة الهاتف'
              )}
            </div>
          ) : (
            <p className="text-xs text-[#6B7C93]">لم تختر نغمة من هاتفك بعد.</p>
          )}
          <button
            type="button"
            disabled={busy}
            onClick={pickPhoneRingtone}
            className="w-full min-h-[40px] rounded-xl bg-white border border-[#E6EDF5] text-xs font-bold text-[#172B4D] flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <Smartphone className="w-3.5 h-3.5 text-[#2F80ED]" />
            <span>{settings.alarmCustomUri ? 'تغيير نغمة الهاتف' : 'اختيار نغمة من الهاتف'}</span>
          </button>
          <p className="text-[11px] text-[#6B7C93] leading-relaxed">
            تعمل هذه النغمة أيضاً عندما يكون التطبيق مغلقاً أو في الخلفية.
          </p>
        </div>
      )}

      {/* أغنياتي */}
      {tab === 'my_song' && (
        <div className="space-y-2">
          {songs.length === 0 && (
            <p className="text-xs text-[#6B7C93]">لا توجد أغانٍ مضافة بعد. أضف ملفاً صوتياً من جهازك.</p>
          )}
          {songs.map((song) => {
            const selected = activeSource === 'my_song' && settings.alarmCustomSongId === song.id;
            return (
              <div
                key={song.id}
                role="radio"
                aria-checked={selected}
                onClick={() => onChange({ alarmSoundSource: 'my_song', alarmCustomSongId: song.id })}
                className={`${rowBase} ${selected ? rowOn : rowOff}`}
              >
                <span
                  className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                    selected ? 'border-[#2F80ED] bg-[#2F80ED]' : 'border-[#CBD5E1]'
                  }`}
                >
                  {selected && <Check className="w-3 h-3 text-white" />}
                </span>
                <div className="flex-1 min-w-0">
                  <span className="text-xs font-bold text-[#172B4D] block truncate">{song.name}</span>
                  <span className="text-[11px] text-[#6B7C93] block font-mono">
                    {formatSecondsMMSS(song.durationSeconds)}
                  </span>
                </div>
                {previewBtn(
                  previewId === `song:${song.id}`,
                  () => previewCustom(`song:${song.id}`, 'my_song', song.uri, song.id, 30000),
                  `تجربة ${song.name}`
                )}
                <button
                  type="button"
                  aria-label={`حذف ${song.name}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    void removeSong(song);
                  }}
                  className="min-w-[38px] min-h-[38px] rounded-full bg-rose-50 text-rose-600 flex items-center justify-center cursor-pointer shrink-0"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            );
          })}
          <button
            type="button"
            disabled={busy}
            onClick={addSong}
            className="w-full min-h-[40px] rounded-xl bg-white border border-[#E6EDF5] text-xs font-bold text-[#172B4D] flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <Plus className="w-3.5 h-3.5 text-[#10B981]" />
            <span>إضافة أغنية من الجهاز</span>
          </button>
          <p className="text-[11px] text-[#6B7C93] leading-relaxed">
            تُشغَّل أغنيتك عندما يكون التطبيق مفتوحاً. وفي الخلفية يرنّ منبّه الهاتف الافتراضي، وعند
            فتح التطبيق تتولى أغنيتك الرنين وحدها.
          </p>
        </div>
      )}

      {/* مستوى الصوت */}
      <div className="pt-2 border-t border-[#E6EDF5] space-y-1.5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-[#172B4D] flex items-center gap-1.5">
            <Volume2 className="w-3.5 h-3.5 text-[#2F80ED]" />
            مستوى صوت التنبيه
          </span>
          <span className="font-mono font-bold text-xs text-[#2F80ED]">
            {Math.round(settings.alarmVolume * 100)}%
          </span>
        </div>
        <input
          type="range"
          min={10}
          max={100}
          step={5}
          value={Math.round(settings.alarmVolume * 100)}
          onChange={(e) => onChange({ alarmVolume: Number(e.target.value) / 100 })}
          className="w-full accent-[#1B365D] cursor-pointer"
        />
      </div>

      {message && (
        <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-[11px] font-bold text-amber-800">
          {message}
        </div>
      )}
    </div>
  );
};
