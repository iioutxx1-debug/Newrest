import React from 'react';

interface FunlandLogoProps {
  className?: string;
  size?: number;
}

/** شعار Funland (أرض المرح) — الصورة من public/icon-192.png */
export const FunlandLogo: React.FC<FunlandLogoProps> = ({ className = '', size = 44 }) => {
  return (
    <img
      src="./icon-192.png"
      width={size}
      height={size}
      alt="Funland"
      draggable={false}
      className={`shrink-0 select-none rounded-xl object-cover ${className}`}
    />
  );
};
