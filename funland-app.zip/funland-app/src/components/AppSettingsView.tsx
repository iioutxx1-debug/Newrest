import React, { useState } from 'react';
import { FunlandLogo } from './FunlandLogo';
import { RestSoundPicker } from './RestSoundPicker';
import { loadRestSettings, patchRestSettings } from '../utils/restSettingsStore';
import { getLastBackupTime, shareBackup, restoreFromText } from '../utils/scheduleBackup';
import {
  Volume2,
  Globe,
  Sun,
  Database,
  HelpCircle,
  Info,
  Download,
  Upload,
  RotateCcw,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';

interface AppSettingsViewProps {
  themeMode: 'dark' | 'light';
  onToggleTheme: () => void;
  onResetAllData: () => void;
}

export const AppSettingsView: React.FC<AppSettingsViewProps> = ({
  themeMode,
  onToggleTheme,
  onResetAllData,
}) => {
  const [subScreen, setSubScreen] = useState<
    'main' | 'sound' | 'storage' | 'help' | 'about'
  >('main');

  const [restSettings, setRestSettings] = useState(() => loadRestSettings());
  const vibrationEnabled = restSettings.enableVibration;
  const [confirmResetModal, setConfirmResetModal] = useState(false);
  const [statusNotice, setStatusNotice] = useState<string | null>(null);

  const lastBackup = getLastBackupTime();
  const lastBackupLabel = lastBackup
    ? new Date(lastBackup).toLocaleString('ar', { dateStyle: 'medium', timeStyle: 'short' })
    : null;

  const handleShareSchedulesBackup = async () => {
    try {
      const ok = await shareBackup();
      setStatusNotice(ok ? 'تم تجهيز نسخة الجداول للمشاركة.' : 'لا توجد جداول محفوظة بعد لنسخها.');
    } catch {
      setStatusNotice('تم الإلغاء أو تعذّرت المشاركة.');
    }
  };

  const handleRestoreSchedules = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const ok = restoreFromText(String(ev.target?.result || ''));
      if (ok) {
        setStatusNotice('تم استرجاع الجداول وسجلها بنجاح! جاري التحديث...');
        setTimeout(() => window.location.reload(), 900);
      } else {
        setStatusNotice('الملف ليس نسخة احتياطية صالحة للجداول.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleExportAll = () => {
    const payload: Record<string, unknown> = {};
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && (k.startsWith('miqat_') || k.startsWith('fl_'))) {
        try {
          payload[k] = JSON.parse(localStorage.getItem(k) || 'null');
        } catch {
          payload[k] = localStorage.getItem(k);
        }
      }
    }
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `funland-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setStatusNotice('تم تصدير النسخة الاحتياطية لجميع بيانات التطبيق بنجاح.');
  };

  const handleImportAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = JSON.parse(String(ev.target?.result || '{}'));
        Object.keys(data).forEach((k) => {
          if ((k.startsWith('miqat_') || k.startsWith('fl_'))) {
            localStorage.setItem(k, JSON.stringify(data[k]));
          }
        });
        setStatusNotice('تمت استعادة البيانات بنجاح! جاري تحديث الواجهة...');
        setTimeout(() => window.location.reload(), 1000);
      } catch {
        setStatusNotice('ملف النسخة الاحتياطية غير صالح.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-5">
      {statusNotice && (
        <div className="sm-card p-4 border-emerald-500/40 bg-emerald-50 text-emerald-900 text-xs font-bold flex items-center justify-between">
          <span>{statusNotice}</span>
          <button
            onClick={() => setStatusNotice(null)}
            className="text-emerald-700 underline cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      )}

      {/* =====================================================
          MAIN SETTINGS LIST
         ===================================================== */}
      {subScreen === 'main' && (
        <div className="space-y-4">
          <h2 className="text-2xl font-bold text-[#172B4D]">الإعدادات</h2>

          <div className="space-y-3">
            {/* Row 1: الصوت والاهتزاز */}
            <button
              type="button"
              onClick={() => setSubScreen('sound')}
              className="w-full sm-card p-4 flex items-center justify-between hover:border-[#2F80ED]/50 transition-all cursor-pointer"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-[#EBF3FE] text-[#2F80ED] flex items-center justify-center">
                  <Volume2 className="w-5 h-5" />
                </div>
                <span className="text-sm font-bold text-[#172B4D]">
                  الصوت والاهتزاز
                </span>
              </div>
              <ChevronLeft className="w-4 h-4 text-[#6B7C93]" />
            </button>

            {/* Row 3: اللغة */}
            <div className="w-full sm-card p-4 flex items-center justify-between">
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-[#EBF3FE] text-[#2F80ED] flex items-center justify-center">
                  <Globe className="w-5 h-5" />
                </div>
                <span className="text-sm font-bold text-[#172B4D]">اللغة</span>
              </div>
              <div className="flex items-center gap-2 text-xs font-bold text-[#6B7C93]">
                <span>العربية</span>
                <ChevronLeft className="w-4 h-4" />
              </div>
            </div>

            {/* Row 4: المظهر */}
            <button
              type="button"
              onClick={onToggleTheme}
              className="w-full sm-card p-4 flex items-center justify-between hover:border-[#2F80ED]/50 transition-all cursor-pointer"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-[#EBF3FE] text-[#1B365D] flex items-center justify-center">
                  <Sun className="w-5 h-5" />
                </div>
                <span className="text-sm font-bold text-[#172B4D]">المظهر</span>
              </div>
              <div className="flex items-center gap-2 text-xs font-bold text-[#6B7C93]">
                <span>{themeMode === 'light' ? 'فاتح' : 'داكن'}</span>
                <ChevronLeft className="w-4 h-4" />
              </div>
            </button>

            {/* Row 5: البيانات والتخزين */}
            <button
              type="button"
              onClick={() => setSubScreen('storage')}
              className="w-full sm-card p-4 flex items-center justify-between hover:border-[#2F80ED]/50 transition-all cursor-pointer"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-[#EBF3FE] text-[#1B365D] flex items-center justify-center">
                  <Database className="w-5 h-5" />
                </div>
                <span className="text-sm font-bold text-[#172B4D]">
                  البيانات والتخزين
                </span>
              </div>
              <ChevronLeft className="w-4 h-4 text-[#6B7C93]" />
            </button>

            {/* Row 6: مساعدة ودعم */}
            <button
              type="button"
              onClick={() => setSubScreen('help')}
              className="w-full sm-card p-4 flex items-center justify-between hover:border-[#2F80ED]/50 transition-all cursor-pointer"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-[#EBF3FE] text-[#2F80ED] flex items-center justify-center">
                  <HelpCircle className="w-5 h-5" />
                </div>
                <span className="text-sm font-bold text-[#172B4D]">
                  مساعدة ودعم
                </span>
              </div>
              <ChevronLeft className="w-4 h-4 text-[#6B7C93]" />
            </button>

            {/* Row 7: حول التطبيق */}
            <button
              type="button"
              onClick={() => setSubScreen('about')}
              className="w-full sm-card p-4 flex items-center justify-between hover:border-[#2F80ED]/50 transition-all cursor-pointer"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-[#EBF3FE] text-[#2F80ED] flex items-center justify-center">
                  <Info className="w-5 h-5" />
                </div>
                <span className="text-sm font-bold text-[#172B4D]">
                  حول التطبيق
                </span>
              </div>
              <ChevronLeft className="w-4 h-4 text-[#6B7C93]" />
            </button>
          </div>
        </div>
      )}

      {/* =====================================================
          SUB-SCREEN: SOUND & VIBRATION
         ===================================================== */}
      {subScreen === 'sound' && (
        <div className="sm-card p-6 space-y-5">
          <div className="flex items-center justify-between border-b border-[#E6EDF5] pb-3.5">
            <button
              type="button"
              onClick={() => setSubScreen('main')}
              className="min-h-[38px] px-2.5 rounded-xl hover:bg-slate-100 text-[#172B4D] flex items-center gap-1 text-xs font-bold cursor-pointer"
            >
              <ChevronRight className="w-5 h-5" />
              <span>رجوع</span>
            </button>
            <h3 className="text-lg font-bold text-[#172B4D]">الصوت والاهتزاز</h3>
            <div className="w-12" />
          </div>

          <RestSoundPicker
            settings={restSettings}
            onChange={(patch) => setRestSettings(patchRestSettings(patch))}
          />

          <div className="flex items-center justify-between pt-2 border-t border-[#E6EDF5]">
            <span className="text-sm font-bold text-[#172B4D]">
              تفعيل الاهتزاز عند انتهاء الاستراحة
            </span>
            <button
              type="button"
              onClick={() =>
                setRestSettings(patchRestSettings({ enableVibration: !vibrationEnabled }))
              }
              className={`w-14 h-8 rounded-full p-1 transition-colors cursor-pointer flex items-center ${
                vibrationEnabled
                  ? 'bg-[#22C55E] justify-end'
                  : 'bg-[#CBD5E1] justify-start'
              }`}
            >
              <span className="w-6 h-6 rounded-full bg-white shadow-xs block" />
            </button>
          </div>
        </div>
      )}

      {/* =====================================================
          SUB-SCREEN: DATA & STORAGE
         ===================================================== */}
      {subScreen === 'storage' && (
        <div className="sm-card p-6 space-y-5">
          <div className="flex items-center justify-between border-b border-[#E6EDF5] pb-3.5">
            <button
              type="button"
              onClick={() => setSubScreen('main')}
              className="min-h-[38px] px-2.5 rounded-xl hover:bg-slate-100 text-[#172B4D] flex items-center gap-1 text-xs font-bold cursor-pointer"
            >
              <ChevronRight className="w-5 h-5" />
              <span>رجوع</span>
            </button>
            <h3 className="text-lg font-bold text-[#172B4D]">البيانات والتخزين</h3>
            <div className="w-12" />
          </div>

          <p className="text-xs text-[#6B7C93] leading-relaxed">
            يتم حفظ جداول فن لاند واستراحات الموظفين وسجلات التقارير محلياً على جهازك دون الحاجة لأي اتصال بالإنترنت.
          </p>

          <div className="rounded-2xl border border-[#D6E6FB] bg-[#F5F9FF] p-4 space-y-3">
            <div className="flex items-center gap-2 text-[#1B365D] font-bold text-sm">
              <ShieldCheck className="w-4 h-4 text-[#10B981]" />
              <span>ذاكرة الجداول (تبقى حتى لو حذفت التطبيق)</span>
            </div>
            <p className="text-[11px] text-[#6B7C93] leading-relaxed">
              يحفظ التطبيق تلقائياً آخر جدول وسجل الجداول بالتاريخ في مجلد المستندات (Documents/Funland).
              عند إعادة تثبيت التطبيق يسترجعها تلقائياً. للأمان الكامل احتفظ بنسخة خارجية أيضاً (واتساب/درايف).
            </p>
            <p className="text-[11px] font-bold text-[#172B4D]">
              {lastBackupLabel ? `آخر حفظ تلقائي: ${lastBackupLabel}` : 'لم يتم الحفظ التلقائي بعد'}
            </p>
            <button
              onClick={handleShareSchedulesBackup}
              className="w-full min-h-[44px] rounded-xl bg-white hover:bg-[#EBF3FE] border border-[#D6E6FB] text-[#1B365D] font-bold text-xs flex items-center justify-center gap-2 cursor-pointer"
            >
              <Download className="w-4 h-4 text-[#2F80ED]" />
              <span>حفظ نسخة خارجية للجداول (مشاركة)</span>
            </button>
            <label className="w-full min-h-[44px] rounded-xl bg-white hover:bg-[#EBF3FE] border border-[#D6E6FB] text-[#1B365D] font-bold text-xs flex items-center justify-center gap-2 cursor-pointer">
              <Upload className="w-4 h-4 text-[#10B981]" />
              <span>استرجاع الجداول من ملف</span>
              <input
                type="file"
                accept="application/json,.json"
                onChange={handleRestoreSchedules}
                className="hidden"
              />
            </label>
          </div>

          <div className="space-y-3">
            <button
              onClick={handleExportAll}
              className="w-full min-h-[48px] rounded-2xl bg-[#EBF3FE] hover:bg-[#DCE8F8] text-[#1B365D] font-bold text-xs flex items-center justify-center gap-2 cursor-pointer"
            >
              <Download className="w-4 h-4 text-[#2F80ED]" />
              <span>تصدير نسخة احتياطية كاملة (JSON)</span>
            </button>

            <label className="w-full min-h-[48px] rounded-2xl bg-[#F0F4F9] hover:bg-[#E2E8F0] text-[#172B4D] font-bold text-xs flex items-center justify-center gap-2 cursor-pointer">
              <Upload className="w-4 h-4 text-[#10B981]" />
              <span>استعادة نسخة احتياطية من ملف</span>
              <input
                type="file"
                accept="application/json"
                onChange={handleImportAll}
                className="hidden"
              />
            </label>

            <button
              onClick={() => setConfirmResetModal(true)}
              className="w-full min-h-[48px] rounded-2xl bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>إعادة ضبط المصنع واستعادة البيانات الافتراضية</span>
            </button>
          </div>
        </div>
      )}

      {/* =====================================================
          SUB-SCREEN: HELP & SUPPORT
         ===================================================== */}
      {subScreen === 'help' && (
        <div className="sm-card p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-[#E6EDF5] pb-3.5">
            <button
              type="button"
              onClick={() => setSubScreen('main')}
              className="min-h-[38px] px-2.5 rounded-xl hover:bg-slate-100 text-[#172B4D] flex items-center gap-1 text-xs font-bold cursor-pointer"
            >
              <ChevronRight className="w-5 h-5" />
              <span>رجوع</span>
            </button>
            <h3 className="text-lg font-bold text-[#172B4D]">مساعدة ودعم</h3>
            <div className="w-12" />
          </div>

          <div className="space-y-3 text-xs text-[#172B4D] leading-relaxed">
            <p className="font-bold text-[#1B365D]">
              كيف تضمن عمل تنبيهات استراحات الموظفين بأفضل دقة على أندرويد؟
            </p>
            <ul className="list-disc pr-5 space-y-1.5 text-[#6B7C93]">
              <li>اسمح للتطبيق بصلاحية الإشعارات والمنبهات الدقيقة عند تثبيت الـ APK.</li>
              <li>فعّل خيار إبقاء الشاشة مضاءة (Wake Lock) أثناء متابعة مؤقتات الاستراحات.</li>
              <li>تجنب إغلاق التطبيق قسرياً (Force Stop) من إعدادات النظام.</li>
            </ul>
          </div>
        </div>
      )}

      {/* =====================================================
          SUB-SCREEN: ABOUT FUNLAND
         ===================================================== */}
      {subScreen === 'about' && (
        <div className="sm-card p-6 text-center space-y-4">
          <div className="flex items-center justify-between border-b border-[#E6EDF5] pb-3.5">
            <button
              type="button"
              onClick={() => setSubScreen('main')}
              className="min-h-[38px] px-2.5 rounded-xl hover:bg-slate-100 text-[#172B4D] flex items-center gap-1 text-xs font-bold cursor-pointer"
            >
              <ChevronRight className="w-5 h-5" />
              <span>رجوع</span>
            </button>
            <h3 className="text-lg font-bold text-[#172B4D]">حول التطبيق</h3>
            <div className="w-12" />
          </div>

          <div className="py-4 flex flex-col items-center space-y-2">
            <FunlandLogo size={96} />
            <h4 className="text-xl font-bold text-[#1B365D]">Funland</h4>
            <p className="text-sm font-bold text-[#2F80ED]">أرض المرح</p>
            <p className="text-xs text-[#6B7C93] max-w-sm">
              جداول فن لاند · إدارة استراحات الموظفين · تقارير الاستراحات
            </p>
          </div>
        </div>
      )}

      {/* Confirm Factory Reset Modal */}
      {confirmResetModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm rounded-3xl bg-white border border-[#E6EDF5] p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-bold text-[#172B4D]">
              تأكيد إعادة ضبط البيانات
            </h3>
            <p className="text-xs text-[#6B7C93] leading-relaxed">
              هل أنت متأكد من مسح جميع البيانات المخصصة واستعادة الإعدادات الافتراضية للتطبيق؟
            </p>
            <div className="flex items-center justify-end gap-3">
              <button
                onClick={() => setConfirmResetModal(false)}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-[#F0F4F9] text-[#6B7C93] text-xs font-bold cursor-pointer"
              >
                إلغاء
              </button>
              <button
                onClick={() => {
                  setConfirmResetModal(false);
                  onResetAllData();
                }}
                className="min-h-[40px] px-5 py-2 rounded-xl bg-rose-600 text-white text-xs font-bold cursor-pointer"
              >
                تأكيد المسح
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
