/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { EmployeeRestManager } from './components/EmployeeRestManager';
import { ReportsAnalyticsView } from './components/ReportsAnalyticsView';
import { AppSettingsView } from './components/AppSettingsView';
import { FunlandLogo } from './components/FunlandLogo';
import { nativeAlarmBridge } from './utils/nativeAlarmBridge';
import {
  CheckCircle2,
  Users,
  Home,
  BarChart3,
  Settings,
  Menu,
  X,
  CalendarDays,
} from 'lucide-react';

export type ActiveSection = 'home' | 'schedules' | 'rest' | 'reports' | 'settings';

const STORAGE_KEYS = {
  THEME: 'miqat_fajr_theme_v2_light',
};

// مفاتيح بيانات المنبه القديمة (من نسخة SmartMorning) — تُحذف مرة واحدة عند أول تشغيل
const LEGACY_KEYS = [
  'miqat_fajr_alarms_v1',
  'miqat_fajr_default_tone_v1',
  'miqat_fajr_default_tone_config_v1',
  'miqat_fajr_routine_v1',
  'miqat_fajr_habits_v1',
];

export default function App() {
  const [activeSection, setActiveSection] = useState<ActiveSection>('home');
  const [drawerOpen, setDrawerOpen] = useState(false);
  // الجداول تبقى محمّلة بعد أول فتح حتى لا تضيع بيانات الشاشة عند التنقل
  const [schedulesVisited, setSchedulesVisited] = useState(false);
  const schedulesFrameRef = useRef<HTMLIFrameElement>(null);

  // Theme Mode: Default is 'light'
  const [themeMode, setThemeMode] = useState<'dark' | 'light'>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.THEME);
      return saved === 'dark' ? 'dark' : 'light';
    } catch {
      return 'light';
    }
  });

  const [toastBanner, setToastBanner] = useState<string | null>(null);

  // تنظيف بيانات المنبه القديمة وإلغاء أي إشعارات منبه مجدولة من النسخة السابقة
  useEffect(() => {
    try {
      LEGACY_KEYS.forEach((k) => localStorage.removeItem(k));
    } catch {}
    nativeAlarmBridge.clearLegacyAlarmNotifications();
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.THEME, themeMode);
    } catch {}
  }, [themeMode]);

  useEffect(() => {
    if (activeSection === 'schedules') setSchedulesVisited(true);
  }, [activeSection]);

  // مزامنة مظهر صفحة الجداول (فاتح/داكن) مع مظهر التطبيق
  const syncSchedulesTheme = () => {
    try {
      const doc = schedulesFrameRef.current?.contentDocument;
      if (doc) doc.documentElement.setAttribute('data-theme', themeMode);
    } catch {}
  };
  useEffect(() => {
    syncSchedulesTheme();
  }, [themeMode, schedulesVisited]);

  const showToast = (msg: string) => {
    setToastBanner(msg);
    setTimeout(() => setToastBanner(null), 4000);
  };

  const handleResetAllData = () => {
    localStorage.clear();
    showToast('تمت استعادة الإعدادات والبيانات الافتراضية بنجاح.');
    setTimeout(() => window.location.reload(), 800);
  };

  const navMenuItems: { id: ActiveSection; label: string; icon: React.ReactNode }[] = [
    { id: 'home', label: 'الرئيسية', icon: <Home className="w-4 h-4" /> },
    { id: 'schedules', label: 'جداول فن لاند', icon: <CalendarDays className="w-4 h-4" /> },
    { id: 'rest', label: 'إدارة الاستراحات', icon: <Users className="w-4 h-4" /> },
    { id: 'reports', label: 'التقارير', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'settings', label: 'الإعدادات', icon: <Settings className="w-4 h-4" /> },
  ];

  const mobileNavItems: { id: ActiveSection; label: string; icon: React.ReactNode }[] = [
    { id: 'home', label: 'الرئيسية', icon: <Home className="w-5 h-5" /> },
    { id: 'schedules', label: 'الجداول', icon: <CalendarDays className="w-5 h-5" /> },
    { id: 'rest', label: 'الاستراحات', icon: <Users className="w-5 h-5" /> },
    { id: 'reports', label: 'التقارير', icon: <BarChart3 className="w-5 h-5" /> },
  ];

  return (
    <div
      className={`min-h-screen flex flex-col pb-22 md:pb-8 transition-colors ${
        themeMode === 'dark' ? 'dark-theme' : ''
      }`}
    >
      {/* Top Header Bar */}
      <header className="sticky top-0 z-30 flex items-center justify-between px-4 sm:px-8 py-3.5 border-b border-[#E6EDF5] bg-white/95 backdrop-blur-md text-[#172B4D] shadow-2xs">
        {/* Zone 1: Drawer Menu Button + Brand Lockup */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setDrawerOpen(true)}
            className="min-h-[42px] min-w-[42px] rounded-xl bg-[#F0F4F9] hover:bg-[#E2E8F0] flex items-center justify-center text-[#1B365D] cursor-pointer transition-colors"
            title="القائمة الجانبية"
          >
            <Menu className="w-5 h-5" />
          </button>

          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              setActiveSection('home');
            }}
            className="flex items-center gap-2.5"
          >
            <FunlandLogo size={38} />
            <div className="leading-tight">
              <span className="block text-base sm:text-lg font-extrabold tracking-tight text-[#1B365D] font-display">
                Funland
              </span>
              <span className="block text-[11px] font-bold text-[#2F80ED]">أرض المرح</span>
            </div>
          </a>
        </div>

        {/* Zone 2: Desktop Navigation Pills */}
        <nav className="hidden lg:flex items-center gap-1.5 bg-[#F4F7FB] p-1.5 rounded-2xl border border-[#E6EDF5]">
          {navMenuItems.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveSection(item.id)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                  isActive
                    ? 'bg-[#1B365D] text-white shadow-xs'
                    : 'text-[#6B7C93] hover:text-[#172B4D]'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Settings shortcut */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveSection('settings')}
            className="min-h-[42px] min-w-[42px] rounded-xl bg-[#F0F4F9] hover:bg-[#E2E8F0] flex items-center justify-center text-[#1B365D] cursor-pointer transition-colors"
            title="الإعدادات"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* =========================================================
          SLIDE-OVER SIDEBAR DRAWER
         ========================================================= */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div
            onClick={() => setDrawerOpen(false)}
            className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs"
          />

          <aside className="relative z-10 w-72 max-w-[85vw] bg-gradient-to-b from-[#1B365D] via-[#14294A] to-[#0D1B32] p-6 flex flex-col justify-between text-white shadow-2xl overflow-y-auto">
            <div className="space-y-6">
              <div className="relative flex flex-col items-center text-center pt-2 space-y-2">
                <button
                  onClick={() => setDrawerOpen(false)}
                  className="absolute top-0 left-0 min-h-[36px] min-w-[36px] rounded-xl bg-white/10 text-white/80 hover:text-white flex items-center justify-center cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>

                <FunlandLogo size={84} />
                <div>
                  <h2 className="text-xl font-extrabold tracking-tight text-white">Funland</h2>
                  <p className="text-xs font-bold text-amber-300 mt-0.5">أرض المرح</p>
                </div>
              </div>

              <div className="space-y-1.5 pt-3 border-t border-white/10">
                {navMenuItems.map((item) => {
                  const active = activeSection === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveSection(item.id);
                        setDrawerOpen(false);
                      }}
                      className={`w-full min-h-[44px] px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-3 transition-colors cursor-pointer ${
                        active
                          ? 'bg-white text-[#1B365D] shadow-md'
                          : 'text-slate-100 hover:bg-white/10'
                      }`}
                    >
                      <span className={active ? 'text-[#2F80ED]' : 'text-amber-300'}>
                        {item.icon}
                      </span>
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content Container */}
      <main className="flex-1 w-full max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Toast Notification Banner */}
        {toastBanner && (
          <div className="sm-card border-emerald-500/40 bg-[#E6F8EF] px-4 py-3 text-xs font-bold text-[#065F46] flex items-center justify-between shadow-md">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0" />
              <span>{toastBanner}</span>
            </div>
            <button
              onClick={() => setToastBanner(null)}
              className="text-[#065F46] hover:underline text-xs font-bold cursor-pointer"
            >
              إغلاق
            </button>
          </div>
        )}

        {/* Always-mounted EmployeeRestManager:
            - When activeSection === 'rest', renders full Employee Rest Manager UI.
            - On other tabs, keeps timers/notification action handlers alive and shows the Rest Alert Banner if a rest expires. */}
        <EmployeeRestManager
          onNavigateToRest={() => setActiveSection('rest')}
          isRestTabVisible={activeSection === 'rest'}
        />

        {/* =====================================================
            HOME (الرئيسية)
           ===================================================== */}
        {activeSection === 'home' && (
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <FunlandLogo size={64} />
              <div>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172B4D]">
                  أهلاً بك في Funland
                </h1>
                <p className="text-xs sm:text-sm text-[#6B7C93] font-medium mt-0.5">
                  جداول فن لاند وإدارة الاستراحات في تطبيق واحد
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <button
                onClick={() => setActiveSection('schedules')}
                className="sm-card p-5 hover:border-[#F59E0B] flex flex-col items-center justify-center text-center gap-3 transition-all cursor-pointer group"
              >
                <div className="w-14 h-14 rounded-2xl bg-[#FEF3C7] text-[#F59E0B] flex items-center justify-center group-hover:scale-105 transition-transform">
                  <CalendarDays className="w-7 h-7" />
                </div>
                <div>
                  <span className="text-sm sm:text-base font-extrabold text-[#172B4D] block">
                    جداول فن لاند
                  </span>
                  <span className="text-[11px] font-semibold text-[#6B7C93]">
                    إنشاء الجدول وتصديره PDF / صورة
                  </span>
                </div>
              </button>

              <button
                onClick={() => setActiveSection('rest')}
                className="sm-card p-5 hover:border-[#2F80ED] flex flex-col items-center justify-center text-center gap-3 transition-all cursor-pointer group"
              >
                <div className="w-14 h-14 rounded-2xl bg-[#EBF3FE] text-[#1B365D] flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Users className="w-7 h-7 text-[#2F80ED]" />
                </div>
                <div>
                  <span className="text-sm sm:text-base font-extrabold text-[#172B4D] block">
                    إدارة الاستراحات
                  </span>
                  <span className="text-[11px] font-semibold text-[#6B7C93]">
                    مؤقتات وأرصدة الموظفين
                  </span>
                </div>
              </button>

              <button
                onClick={() => setActiveSection('reports')}
                className="sm-card p-5 hover:border-[#10B981] flex flex-col items-center justify-center text-center gap-3 transition-all cursor-pointer group"
              >
                <div className="w-14 h-14 rounded-2xl bg-[#E6F8EF] text-[#10B981] flex items-center justify-center group-hover:scale-105 transition-transform">
                  <BarChart3 className="w-7 h-7" />
                </div>
                <div>
                  <span className="text-sm sm:text-base font-extrabold text-[#172B4D] block">
                    التقارير
                  </span>
                  <span className="text-[11px] font-semibold text-[#6B7C93]">
                    إحصائيات الاستراحات
                  </span>
                </div>
              </button>
            </div>
          </div>
        )}

        {/* =====================================================
            SCHEDULES (جداول فن لاند) — صفحة الجداول الأصلية داخل التطبيق
           ===================================================== */}
        {schedulesVisited && (
          <div
            className={`sm-card overflow-hidden p-0 ${
              activeSection === 'schedules' ? '' : 'hidden'
            }`}
          >
            <iframe
              ref={schedulesFrameRef}
              src="./schedules.html"
              title="جداول فن لاند"
              onLoad={syncSchedulesTheme}
              className="block w-full border-0 bg-white"
              style={{ height: 'calc(100dvh - 11rem)', minHeight: 480 }}
            />
          </div>
        )}

        {/* =====================================================
            REPORTS (التقارير)
           ===================================================== */}
        {activeSection === 'reports' && <ReportsAnalyticsView />}

        {/* =====================================================
            SETTINGS (الإعدادات)
           ===================================================== */}
        {activeSection === 'settings' && (
          <AppSettingsView
            themeMode={themeMode}
            onToggleTheme={() =>
              setThemeMode((prev) => (prev === 'dark' ? 'light' : 'dark'))
            }
            onResetAllData={handleResetAllData}
          />
        )}
      </main>

      {/* Fixed Bottom Navigation Bar for Mobile / Android */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-[#E6EDF5] px-2 py-1.5 md:hidden shadow-lg">
        <div className="grid grid-cols-4 gap-1.5 max-w-md mx-auto">
          {mobileNavItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveSection(item.id)}
              className={`min-h-[48px] rounded-xl flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-colors ${
                activeSection === item.id
                  ? 'text-[#1B365D] font-extrabold bg-[#EBF3FE]'
                  : 'text-[#6B7C93]'
              }`}
            >
              {item.icon}
              <span className="text-[10px]">{item.label}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}
