/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { EmployeeRestManager } from './components/EmployeeRestManager';
import { ReportsAnalyticsView } from './components/ReportsAnalyticsView';
import { AppSettingsView } from './components/AppSettingsView';
import { FunlandLogo } from './components/FunlandLogo';
import { nativeAlarmBridge } from './utils/nativeAlarmBridge';
import { startScheduleExportListener } from './utils/scheduleExport';
import {
  restoreIfEmpty,
  startAutoBackup,
  deleteBackupFiles,
  type RestoreResult,
} from './utils/scheduleBackup';
import {
  CheckCircle2,
  Users,
  Home,
  BarChart3,
  Settings,
  Menu,
  X,
  CalendarDays,
  MapPin,
  Clock,
} from 'lucide-react';

export type ActiveSection = 'home' | 'schedules' | 'rest' | 'reports' | 'settings';

const STORAGE_KEYS = {
  THEME: 'miqat_fajr_theme_v2_light',
  CLOCK_FORMAT: 'funland_clock_format_v1',
};

// مفاتيح بيانات المنبه القديمة (من نسخة SmartMorning) — تُحذف مرة واحدة عند أول تشغيل
const LEGACY_KEYS = [
  'miqat_fajr_alarms_v1',
  'miqat_fajr_default_tone_v1',
  'miqat_fajr_default_tone_config_v1',
  'miqat_fajr_routine_v1',
  'miqat_fajr_habits_v1',
];

export default function App() {
  const [activeSection, setSection] = useState<ActiveSection>('home');
  const [drawerOpen, setDrawerOpen] = useState(false);
  // الجداول تبقى محمّلة بعد أول فتح حتى لا تضيع بيانات الشاشة عند التنقل
  const [schedulesVisited, setSchedulesVisited] = useState(false);
  const schedulesFrameRef = useRef<HTMLIFrameElement>(null);
  // ذاكرة الجداول: نسترجع آخر نسخة محفوظة (لو التطبيق جديد/أُعيد تثبيته) قبل تحميل صفحة الجداول
  const [restoreState, setRestoreState] = useState<'checking' | RestoreResult>('checking');

  // Theme Mode: Default is 'light'
  const [themeMode, setThemeMode] = useState<'dark' | 'light' | 'system'>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.THEME);
      return saved === 'dark' || saved === 'system' ? saved : 'light';
    } catch { return 'light'; }
  });
  const [systemDark, setSystemDark] = useState(() => typeof window !== 'undefined' && window.matchMedia?.('(prefers-color-scheme: dark)').matches);
  useEffect(() => {
    const media = window.matchMedia('(prefers-color-scheme: dark)');
    const update = () => setSystemDark(media.matches);
    media.addEventListener?.('change', update);
    return () => media.removeEventListener?.('change', update);
  }, []);
  const resolvedTheme: 'dark' | 'light' = themeMode === 'system' ? (systemDark ? 'dark' : 'light') : themeMode;

  // التنقل مع سجل المتصفح: زر الرجوع في أندرويد يرجع للصفحة السابقة بدل إغلاق التطبيق
  const navigate = (section: ActiveSection) => {
    if (section === activeSection) return;
    try {
      history.pushState({ section }, '');
    } catch {}
    setSection(section);
    setDrawerOpen(false);
    try {
      navigator.vibrate?.(8);
    } catch {}
  };

  useEffect(() => {
    try {
      history.replaceState({ section: 'home' }, '');
    } catch {}
    const onPop = (e: PopStateEvent) => {
      const s = e.state?.section as ActiveSection | undefined;
      setSection(s ?? 'home');
      setDrawerOpen(false);
    };
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  const [toastBanner, setToastBanner] = useState<string | null>(null);
  const [clockNow, setClockNow] = useState(() => new Date());
  const [clockFormat, setClockFormat] = useState<'12' | '24'>(() => { try { return localStorage.getItem(STORAGE_KEYS.CLOCK_FORMAT) === '12' ? '12' : '24'; } catch { return '24'; } });
  useEffect(() => { try { localStorage.setItem(STORAGE_KEYS.CLOCK_FORMAT, clockFormat); } catch {} }, [clockFormat]);
  const [locationLabel, setLocationLabel] = useState('وقت الجهاز المحلي');
  const [locationBusy, setLocationBusy] = useState(false);
  const [homeStats, setHomeStats] = useState({ total: 0, active: 0, notStarted: 0, late: 0 });
  useEffect(() => {
    const tick = () => { setClockNow(new Date()); try { const list = JSON.parse(localStorage.getItem('miqat_rest_employees_v1') || '[]'); if (Array.isArray(list)) { const active = list.filter((e: any) => !!e.activeSession); setHomeStats({ total: list.length, active: active.length, notStarted: list.filter((e: any) => !e.hasStartedRestToday && !e.optedOutRemainingToday).length, late: active.filter((e: any) => e.activeSession?.targetEndMs && Date.now() > e.activeSession.targetEndMs).length }); } } catch {} };
    tick(); const timer = window.setInterval(tick, 1000); return () => window.clearInterval(timer);
  }, []);
  const requestLocationForClock = () => {
    if (!navigator.geolocation) { setLocationLabel('الموقع غير مدعوم على هذا الجهاز'); return; }
    setLocationBusy(true);
    navigator.geolocation.getCurrentPosition((pos) => { setLocationLabel(`الموقع مفعّل • ${pos.coords.latitude.toFixed(3)}, ${pos.coords.longitude.toFixed(3)} • ${Intl.DateTimeFormat().resolvedOptions().timeZone || 'التوقيت المحلي'}`); setLocationBusy(false); }, (err) => { setLocationLabel(err.code === 1 ? 'تم رفض إذن الموقع — الساعة تعمل حسب توقيت الجهاز' : 'تعذر تحديد الموقع — الساعة تعمل حسب توقيت الجهاز'); setLocationBusy(false); }, { enableHighAccuracy: false, timeout: 10000, maximumAge: 60000 });
  };

  // استقبال طلبات حفظ/مشاركة الجدول (PNG/PDF/واتساب) القادمة من صفحة الجداول
  useEffect(
    () => startScheduleExportListener(() => schedulesFrameRef.current?.contentWindow),
    []
  );

  // استرجاع تلقائي ثم تشغيل الحفظ التلقائي لسجل الجداول خارج التطبيق
  useEffect(() => {
    let stop: (() => void) | null = null;
    let cancelled = false;
    restoreIfEmpty()
      .catch((): RestoreResult => 'empty')
      .then((r) => {
        if (cancelled) return;
        setRestoreState(r);
        if (r === 'restored') showToast('تم استرجاع آخر جدول وسجل الجداول المحفوظ ✓');
        stop = startAutoBackup();
      });
    return () => {
      cancelled = true;
      stop?.();
    };
  }, []);

  // تنظيف بيانات المنبه القديمة وإلغاء أي إشعارات منبه مجدولة من النسخة السابقة
  useEffect(() => {
    try {
      LEGACY_KEYS.forEach((k) => localStorage.removeItem(k));
    } catch {}
    nativeAlarmBridge.clearLegacyAlarmNotifications();
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.THEME, themeMode);
    } catch {}
  }, [themeMode]);

  useEffect(() => {
    if (activeSection === 'schedules') setSchedulesVisited(true);
  }, [activeSection]);

  // مزامنة مظهر صفحة الجداول (فاتح/داكن) مع مظهر التطبيق
  const syncSchedulesTheme = () => {
    try {
      const doc = schedulesFrameRef.current?.contentDocument;
      if (doc) doc.documentElement.setAttribute('data-theme', resolvedTheme);
    } catch {}
  };
  useEffect(() => {
    syncSchedulesTheme();
  }, [resolvedTheme, schedulesVisited]);

  const showToast = (msg: string) => {
    setToastBanner(msg);
    setTimeout(() => setToastBanner(null), 4000);
  };

  const handleResetAllData = async () => {
    const savedPin = localStorage.getItem('funland_admin_pin_v1');
    if (savedPin) { const entered = window.prompt('أدخل رمز المدير لتأكيد حذف جميع البيانات:'); if (entered !== savedPin) { showToast('رمز المدير غير صحيح؛ لم يتم حذف البيانات.'); return; } } else { const confirmPin = window.prompt('لحماية حذف البيانات، أنشئ رمز مدير من 4 أرقام على الأقل الآن:'); if (!confirmPin || confirmPin.length < 4) { showToast('تم إلغاء العملية. يجب أن يكون الرمز 4 أحرف/أرقام على الأقل.'); return; } localStorage.setItem('funland_admin_pin_v1', confirmPin); const verifyPin = window.prompt('أعد إدخال رمز المدير لتأكيد الحذف:'); if (verifyPin !== confirmPin) { showToast('الرمزان غير متطابقين؛ لم يتم حذف البيانات.'); return; } }
    await deleteBackupFiles();
    localStorage.clear();
    showToast('تمت استعادة الإعدادات والبيانات الافتراضية بنجاح.');
    setTimeout(() => window.location.reload(), 800);
  };

  const navMenuItems: { id: ActiveSection; label: string; icon: React.ReactNode }[] = [
    { id: 'home', label: 'الرئيسية', icon: <Home className="w-4 h-4" /> },
    { id: 'schedules', label: 'جداول فن لاند', icon: <CalendarDays className="w-4 h-4" /> },
    { id: 'rest', label: 'إدارة الاستراحات', icon: <Users className="w-4 h-4" /> },
    { id: 'reports', label: 'التقارير', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'settings', label: 'الإعدادات', icon: <Settings className="w-4 h-4" /> },
  ];

  const mobileNavItems: { id: ActiveSection; label: string; icon: React.ReactNode }[] = [
    { id: 'home', label: 'الرئيسية', icon: <Home className="w-5 h-5" /> },
    { id: 'schedules', label: 'الجداول', icon: <CalendarDays className="w-5 h-5" /> },
    { id: 'rest', label: 'الاستراحات', icon: <Users className="w-5 h-5" /> },
    { id: 'reports', label: 'التقارير', icon: <BarChart3 className="w-5 h-5" /> },
    { id: 'settings', label: 'الإعدادات', icon: <Settings className="w-5 h-5" /> },
  ];

  return (
    <div
      className={`min-h-screen flex flex-col pb-22 md:pb-8 transition-colors ${
        resolvedTheme === 'dark' ? 'dark-theme' : ''
      }`}
    >
      {/* Top Header Bar */}
      <header className="safe-top sticky top-0 z-30 flex items-center justify-between px-4 sm:px-8 py-3.5 border-b border-[#E6EDF5] bg-white/95 backdrop-blur-md text-[#172B4D] shadow-2xs">
        {/* Zone 1: Drawer Menu Button + Brand Lockup */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setDrawerOpen(true)}
            className="min-h-[42px] min-w-[42px] rounded-xl bg-[#F0F4F9] hover:bg-[#E2E8F0] flex items-center justify-center text-[#11636A] cursor-pointer transition-colors"
            title="القائمة الجانبية"
          >
            <Menu className="w-5 h-5" />
          </button>

          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              navigate('home');
            }}
            className="flex items-center gap-2.5"
          >
            <FunlandLogo size={38} />
            <div className="leading-tight">
              <span className="block text-base sm:text-lg font-extrabold tracking-tight text-[#11636A] font-display">
                Funland
              </span>
              <span className="block text-[11px] font-bold text-[#087F8C]">أرض المرح</span>
            </div>
          </a>
        </div>

        {/* Zone 2: Desktop Navigation Pills */}
        <nav className="hidden lg:flex items-center gap-1.5 bg-[#F4F7FB] p-1.5 rounded-2xl border border-[#E6EDF5]">
          {navMenuItems.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => navigate(item.id)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                  isActive
                    ? 'bg-[#11636A] text-white shadow-xs'
                    : 'text-[#6B7C93] hover:text-[#172B4D]'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Settings shortcut */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate('settings')}
            className="min-h-[42px] min-w-[42px] rounded-xl bg-[#F0F4F9] hover:bg-[#E2E8F0] flex items-center justify-center text-[#11636A] cursor-pointer transition-colors"
            title="الإعدادات"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* =========================================================
          SLIDE-OVER SIDEBAR DRAWER
         ========================================================= */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div
            onClick={() => setDrawerOpen(false)}
            className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs"
          />

          <aside className="drawer-in relative z-10 w-72 max-w-[85vw] bg-gradient-to-b from-[#11636A] via-[#14294A] to-[#0D1B32] p-6 flex flex-col justify-between text-white shadow-2xl overflow-y-auto">
            <div className="space-y-6">
              <div className="relative flex flex-col items-center text-center pt-2 space-y-2">
                <button
                  onClick={() => setDrawerOpen(false)}
                  className="absolute top-0 left-0 min-h-[36px] min-w-[36px] rounded-xl bg-white/10 text-white/80 hover:text-white flex items-center justify-center cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>

                <FunlandLogo size={84} />
                <div>
                  <h2 className="text-xl font-extrabold tracking-tight text-white">Funland</h2>
                  <p className="text-xs font-bold text-amber-300 mt-0.5">أرض المرح</p>
                </div>
              </div>

              <div className="space-y-1.5 pt-3 border-t border-white/10">
                {navMenuItems.map((item) => {
                  const active = activeSection === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        navigate(item.id);
                        setDrawerOpen(false);
                      }}
                      className={`w-full min-h-[44px] px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-3 transition-colors cursor-pointer ${
                        active
                          ? 'bg-white text-[#11636A] shadow-md'
                          : 'text-slate-100 hover:bg-white/10'
                      }`}
                    >
                      <span className={active ? 'text-[#087F8C]' : 'text-amber-300'}>
                        {item.icon}
                      </span>
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content Container */}
      <main className="flex-1 w-full max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Toast Notification Banner */}
        {toastBanner && (
          <div className="sm-card border-emerald-500/40 bg-[#E6F8EF] px-4 py-3 text-xs font-bold text-[#065F46] flex items-center justify-between shadow-md">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0" />
              <span>{toastBanner}</span>
            </div>
            <button
              onClick={() => setToastBanner(null)}
              className="text-[#065F46] hover:underline text-xs font-bold cursor-pointer"
            >
              إغلاق
            </button>
          </div>
        )}

        {/* Always-mounted EmployeeRestManager:
            - When activeSection === 'rest', renders full Employee Rest Manager UI.
            - On other tabs, keeps timers/notification handlers alive and shows the persistent rest counter / alert banners. */}
        <EmployeeRestManager
          onNavigateToRest={() => navigate('rest')}
          isRestTabVisible={activeSection === 'rest'}
        />

        {/* =====================================================
            HOME (الرئيسية)
           ===================================================== */}
        {activeSection === 'home' && (
          <div className="page-enter fl-home-page space-y-6">
            <div className="fl-home-hero flex items-center gap-4">
              <FunlandLogo size={64} />
              <div>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-[#172B4D]">
                  أهلاً بك في Funland
                </h1>
                <p className="text-xs sm:text-sm text-[#6B7C93] font-medium mt-0.5">
                  جداول فن لاند وإدارة الاستراحات في تطبيق واحد
                </p>
              </div>
            </div>

            <div className="sm-card fl-clock-panel p-4 space-y-3 border-t-2" style={{ borderTopColor: '#087F8C' }}>
              <div className="flex items-center gap-3"><Clock className="w-6 h-6 text-sky-500"/><div><p className="text-xs font-bold text-slate-500">الوقت المحلي الحالي</p><p className="text-3xl sm:text-4xl font-extrabold tabular-nums" dir="ltr">{new Intl.DateTimeFormat('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: clockFormat === '12' }).format(clockNow)}</p><p className="text-sm font-bold">{new Intl.DateTimeFormat('ar-IQ', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }).format(clockNow)}</p></div></div>
              <div className="flex flex-wrap items-center justify-between gap-2"><span className="text-xs font-semibold text-slate-500">{locationLabel}</span><button type="button" onClick={requestLocationForClock} disabled={locationBusy} className="min-h-10 rounded-xl bg-sky-600 px-3 py-2 text-xs font-bold text-white disabled:opacity-60"><MapPin className="inline w-4 h-4 ml-1"/>{locationBusy ? 'جارٍ تحديد الموقع...' : 'تفعيل إذن الموقع'}</button></div>
              <p className="text-[11px] text-slate-500">الساعة تقرأ توقيت الجهاز وتُحدّث كل ثانية. إذن الموقع اختياري ولا يغيّر المنطقة الزمنية تلقائياً.</p>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {[{label:'إجمالي الموظفين', value:homeStats.total, color:'text-sky-500', action:'rest' as ActiveSection},{label:'بالاستراحة الآن', value:homeStats.active, color:'text-emerald-500', action:'rest' as ActiveSection},{label:'لم يبدأوا الاستراحة', value:homeStats.notStarted, color:'text-amber-500', action:'rest' as ActiveSection},{label:'تجاوزوا الوقت', value:homeStats.late, color:'text-rose-500', action:'rest' as ActiveSection}].map((stat) => <button key={stat.label} onClick={() => navigate(stat.action)} className="sm-card fl-stat-card p-4 text-right hover:border-sky-400"><span className="block text-xs font-bold text-slate-500">{stat.label}</span><strong className={`block mt-1 text-2xl font-extrabold ${stat.color}`}>{stat.value}</strong><span className="text-[10px] font-bold text-slate-500">اضغط لفتح القائمة</span></button>)}
            </div>

            <div className="sm-card fl-contact-card px-4 py-3 flex flex-wrap items-center justify-between gap-2 border-t-2" style={{ borderTopColor: '#087F8C' }}>
              <div><p className="text-xs font-bold text-slate-500">تطوير وبرمجة</p><p className="text-sm font-extrabold text-[#172B4D]">علي خالد</p></div>
              <a className="text-sm font-bold text-[#087F8C]" href="tel:07875258038" dir="ltr">07875258038</a>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <button
                onClick={() => navigate('schedules')}
                className="sm-card fl-action-card p-5 hover:border-[#F59E0B] flex flex-col items-center justify-center text-center gap-3 transition-all cursor-pointer group"
              >
                <div className="w-14 h-14 rounded-2xl bg-[#FEF3C7] text-[#F59E0B] flex items-center justify-center group-hover:scale-105 transition-transform">
                  <CalendarDays className="w-7 h-7" />
                </div>
                <div>
                  <span className="text-sm sm:text-base font-extrabold text-[#172B4D] block">
                    جداول فن لاند
                  </span>
                  <span className="text-[11px] font-semibold text-[#6B7C93]">
                    إنشاء الجدول وتصديره PDF / صورة
                  </span>
                </div>
              </button>

              <button
                onClick={() => navigate('rest')}
                className="sm-card fl-action-card p-5 hover:border-[#087F8C] flex flex-col items-center justify-center text-center gap-3 transition-all cursor-pointer group"
              >
                <div className="w-14 h-14 rounded-2xl bg-[#E2F7F6] text-[#11636A] flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Users className="w-7 h-7 text-[#087F8C]" />
                </div>
                <div>
                  <span className="text-sm sm:text-base font-extrabold text-[#172B4D] block">
                    إدارة الاستراحات
                  </span>
                  <span className="text-[11px] font-semibold text-[#6B7C93]">
                    مؤقتات وأرصدة الموظفين
                  </span>
                </div>
              </button>

              <button
                onClick={() => navigate('reports')}
                className="sm-card p-5 hover:border-[#10B981] flex flex-col items-center justify-center text-center gap-3 transition-all cursor-pointer group"
              >
                <div className="w-14 h-14 rounded-2xl bg-[#E6F8EF] text-[#10B981] flex items-center justify-center group-hover:scale-105 transition-transform">
                  <BarChart3 className="w-7 h-7" />
                </div>
                <div>
                  <span className="text-sm sm:text-base font-extrabold text-[#172B4D] block">
                    التقارير
                  </span>
                  <span className="text-[11px] font-semibold text-[#6B7C93]">
                    إحصائيات الاستراحات
                  </span>
                </div>
              </button>
            </div>
          </div>
        )}

        {/* =====================================================
            SCHEDULES (جداول فن لاند) — صفحة الجداول الأصلية داخل التطبيق
           ===================================================== */}
        {schedulesVisited && restoreState !== 'checking' && (
          <div
            className={`sm-card overflow-hidden p-0 ${
              activeSection === 'schedules' ? 'page-enter' : 'hidden'
            }`}
          >
            <iframe
              ref={schedulesFrameRef}
              src="./schedules.html"
              title="جداول فن لاند"
              onLoad={syncSchedulesTheme}
              className="block w-full border-0 bg-white"
              style={{ height: 'calc(100dvh - 11rem)', minHeight: 480 }}
            />
          </div>
        )}

        {/* =====================================================
            REPORTS (التقارير)
           ===================================================== */}
        {activeSection === 'reports' && (
          <div className="page-enter">
            <ReportsAnalyticsView />
          </div>
        )}

        {/* =====================================================
            SETTINGS (الإعدادات)
           ===================================================== */}
        {activeSection === 'settings' && (
          <div className="page-enter">
          <AppSettingsView
            themeMode={themeMode}
            onChangeTheme={setThemeMode}
            clockFormat={clockFormat}
            onChangeClockFormat={setClockFormat}
            onResetAllData={handleResetAllData}
          />
          </div>
        )}
      </main>

      {/* Fixed Bottom Navigation Bar for Mobile / Android */}
      <nav className="safe-bottom fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-[#E6EDF5] px-2 py-1.5 md:hidden shadow-lg">
        <div className="grid grid-cols-5 gap-1 max-w-lg mx-auto">
          {mobileNavItems.map((item) => (
            <button
              key={item.id}
              onClick={() => navigate(item.id)}
              className={`min-h-[48px] rounded-xl flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-colors ${
                activeSection === item.id
                  ? 'text-[#087F8C] font-extrabold bg-[#E2F7F6]'
                  : 'text-[#6B7C93]'
              }`}
            >
              {item.icon}
              <span className="text-[10px]">{item.label}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}
