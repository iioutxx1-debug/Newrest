/* جسر التطبيق: يعوّض ميزة التنزيل الخاصة بـ Claude بحفظ/مشاركة الملف على أندرويد.
   الصفحة الأصلية تستدعي claude.use("downloads") ثم dl.save({filename,data}) — هنا نوفّرها. */
(function () {
  // الصفحة تعمل داخل iframe في تطبيق Funland: جسر Capacitor يكون في النافذة الأم
  var cap = window.Capacitor;
  try { if ((!cap || !cap.isNativePlatform) && window.parent && window.parent !== window) cap = window.parent.Capacitor || cap; } catch (e) {}
  var inFrame = false;
  try { inFrame = window.parent !== window; } catch (e) { inFrame = true; }
  var isNative = !!(cap && cap.isNativePlatform && cap.isNativePlatform());
  if (!isNative && inFrame) {
    try { var pc = window.parent.Capacitor; isNative = !!(pc && pc.isNativePlatform && pc.isNativePlatform()); } catch (e) {}
  }

  function toBase64(blob) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result).split(",")[1]); };
      r.onerror = function () { rej(new Error("read failed")); };
      r.readAsDataURL(blob);
    });
  }
  function safeName(n) { return String(n).replace(/[\\\/:*?"<>|]+/g, "-"); }

  function asciiName(n) {
    var m = String(n).match(/\.(png|pdf)$/i);
    var ext = m ? m[0].toLowerCase() : "";
    var d = String(n).replace(/[^0-9]+/g, "-").replace(/^-+|-+$/g, "");
    return "funland-" + (d || Date.now()) + ext;
  }

  // استدعاء إضافة أصلية بعدة طرق (حسب ما يوفره جسر Capacitor في هذا الإصدار)
  function call(plugin, method, opts) {
    opts = opts || {};
    if (typeof cap.nativePromise === "function") return cap.nativePromise(plugin, method, opts);
    if (cap.Plugins && cap.Plugins[plugin] && typeof cap.Plugins[plugin][method] === "function") return cap.Plugins[plugin][method](opts);
    if (typeof cap.registerPlugin === "function") return cap.registerPlugin(plugin)[method](opts);
    return Promise.reject(new Error("plugin " + plugin + " unavailable"));
  }

  async function saveNative(opts) {
    var step = "start";
    try {
      var name = asciiName(opts.filename);
      step = "base64";
      var b64 = await toBase64(opts.data);
      step = "writeFile";
      var w = await call("Filesystem", "writeFile", { path: name, data: b64, directory: "CACHE" });
      step = "share";
      try {
        await call("Share", "share", { title: name, files: [w.uri], dialogTitle: "حفظ / مشاركة الجدول" });
      } catch (e1) {
        var m1 = String((e1 && e1.message) || e1).toLowerCase();
        if (m1.indexOf("cancel") !== -1) throw e1;
        // حل أخير: حفظ في مجلد المستندات
        step = "documents";
        var d = await call("Filesystem", "writeFile", { path: name, data: b64, directory: "DOCUMENTS" });
        try { alert("تم حفظ الملف في مجلد المستندات (Documents):\n" + name); } catch (x) {}
      }
    } catch (e) {
      var msg = String((e && e.message) || e);
      if (msg.toLowerCase().indexOf("cancel") !== -1) { var c = new Error("declined"); c.code = "declined"; throw c; }
      try { alert("تعذر الحفظ (" + step + "):\n" + msg); } catch (x) {}
      throw e;
    }
  }

  async function saveWeb(opts) {
    var url = URL.createObjectURL(opts.data);
    var a = document.createElement("a");
    a.href = url; a.download = safeName(opts.filename);
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
  }

  // إرسال الصورة مباشرة إلى واتساب (بدون قائمة المشاركة العامة)
  async function waNative(opts) {
    var name = asciiName(opts.filename);
    var b64 = await toBase64(opts.data);
    var w = await call("Filesystem", "writeFile", { path: name, data: b64, directory: "CACHE" });
    try {
      await call("SmartMorningNative", "shareToApp", { packageName: "com.whatsapp", path: w.uri, mimeType: "image/png" });
    } catch (e) {
      var msg = String((e && e.message) || e);
      if (msg.indexOf("app_not_installed") !== -1) {
        try { alert("تطبيق واتساب غير مثبت على هذا الجهاز"); } catch (x) {}
        var d = new Error("declined"); d.code = "declined"; throw d;
      }
      // أي خطأ آخر: نرجع لقائمة المشاركة العادية
      return saveNative(opts);
    }
  }

  // داخل iframe: ردّ أندرويد على استدعاءات الإضافات لا يصل إلى الـ iframe (يبقى الطلب معلّقاً)،
  // لذلك نرسل الملف للتطبيق الأم عبر postMessage وهو ينفّذ الحفظ/المشاركة ويرد علينا بالنتيجة.
  function viaParent(kind, opts) {
    return (async function () {
      var name = asciiName(opts.filename);
      var b64 = await toBase64(opts.data);
      return new Promise(function (resolve, reject) {
        var id = "ex" + Date.now() + Math.random().toString(36).slice(2);
        var acked = false, finished = false;
        var ackTimer = setTimeout(function () {
          finish(new Error("التطبيق لم يستجب لطلب الحفظ (لا يوجد مستمع)"));
        }, 6000);
        var maxTimer = setTimeout(function () { finish(new Error("انتهت مهلة الحفظ")); }, 300000);
        function finish(err, res) {
          if (finished) return;
          finished = true;
          clearTimeout(ackTimer); clearTimeout(maxTimer);
          window.removeEventListener("message", onMsg);
          if (err) reject(err); else resolve(res);
        }
        function onMsg(ev) {
          var d = ev.data;
          if (!d || d.id !== id) return;
          if (d.type === "funland-export-ack") { acked = true; clearTimeout(ackTimer); return; }
          if (d.type !== "funland-export-result") return;
          if (d.ok) return finish(null, true);
          var e = new Error(d.error || "تعذر الحفظ");
          if (d.code === "declined") e.code = "declined";
          finish(e);
        }
        window.addEventListener("message", onMsg);
        try {
          window.parent.postMessage({
            type: "funland-export", id: id, kind: kind, name: name,
            mime: (opts.data && opts.data.type) || "image/png", b64: b64
          }, "*");
        } catch (e) { finish(e); }
      });
    })();
  }

  window.claude = {
    use: async function (name) {
      if (name !== "downloads") return null;
      return {
        save: function (o) {
          if (!isNative) return saveWeb(o);
          return inFrame ? viaParent("save", o) : saveNative(o);
        },
        whatsapp: function (o) {
          if (!isNative) return saveWeb(o);
          return inFrame ? viaParent("whatsapp", o) : waNative(o);
        }
      };
    }
  };

  if (isNative && !inFrame) {
    // حدود آمنة للشاشة (شريط الحالة/التنقل) مع الرجوع لـ env() إن لم تتوفر المتغيرات
    var st = document.createElement("style");
    st.textContent = "html{padding-top:var(--safe-area-inset-top,env(safe-area-inset-top,0px))!important;" +
      "padding-bottom:var(--safe-area-inset-bottom,env(safe-area-inset-bottom,0px))!important}";
    document.head.appendChild(st);
  }
})();
